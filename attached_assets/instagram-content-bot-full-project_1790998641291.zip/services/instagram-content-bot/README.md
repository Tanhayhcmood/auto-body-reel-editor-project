# Auto Repair Reel Bot

A Persian-first Telegram workflow for turning auto body repair footage into reviewed Instagram Reels. Processing requires an OpenAI-compatible AI provider: sampled video frames are analyzed visually, then a Persian storyboard specifies the hook and ordered clips. The pipeline fails explicitly when AI is unavailable; it does not substitute heuristic edits or template-based plans.

The bot sends a preview and waits for an explicit Telegram approval. Only then does it use the official Instagram Graph API. It does not automate Instagram passwords, scrape Instagram, or generate fake engagement.

## Architecture

```text
Telegram webhook
    └── Redis / ARQ worker
         ├── Video Analysis Agent (scene/time segments with representative frame sequences)
         ├── Storyboard Agent (segment comparison, five Persian hooks, ordered source clips)
         ├── Caption Agent (Persian caption; preserves the selected hook and CTA)
         ├── Video Editing Agent (AI-ordered 9:16 MP4, reframe, audio, subtitles)
         ├── Cover Agent (selected frame with hook)
         ├── Quality Control Agent (metadata, dimensions, duration, file checks)
         ├── Approval Agent (private preview and approve/reject keyboard)
         ├── Instagram Publishing Agent (official Graph API, after approval only)
         ├── Analytics Agent (fetches post insights)
         └── Learning Agent (stores shop-level hook performance insights)

FastAPI ── PostgreSQL (users, updates, jobs, agent runs, posts, insights)
        └─ Redis (durable background queue)
Shared media volume ── API media endpoint ── Meta's video/cover fetch
```

## Run with Docker Compose

1. Copy `.env.example` to `.env` in this directory:

   ```sh
   cp .env.example .env
   ```
2. Set unique, long random hexadecimal values for `POSTGRES_PASSWORD` and `REDIS_PASSWORD` (for example, generate each with `openssl rand -hex 32`).
3. Set `TELEGRAM_BOT_TOKEN`, a 1–256 character `TELEGRAM_WEBHOOK_SECRET`, and `ALLOWED_TELEGRAM_USER_IDS` to the numeric Telegram user IDs permitted to use and approve posts. Startup is rejected if the allowlist is empty.
4. Start services:

   ```sh
   docker compose up --build
   ```

5. Expose the API through a public HTTPS domain. Set `PUBLIC_MEDIA_BASE_URL` to that origin, then set the Telegram webhook:

   ```sh
   curl -X POST "https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/setWebhook" \
     --data-urlencode "url=${PUBLIC_MEDIA_BASE_URL}/webhooks/telegram" \
     --data-urlencode "secret_token=${TELEGRAM_WEBHOOK_SECRET}"
   ```

6. For Instagram publishing, use the official Instagram API with Facebook Login: an eligible professional account linked to a Facebook Page, the Page access token, and an app granted `instagram_basic`, `instagram_content_publish`, and `pages_read_engagement`. For insights, also grant `instagram_manage_insights`. Set `INSTAGRAM_ACCOUNT_ID`, `META_ACCESS_TOKEN`, and the current supported Graph API version in `META_GRAPH_API_VERSION`. Meta must be able to fetch the generated media URLs from `PUBLIC_MEDIA_BASE_URL`.

7. Configure `AI_API_KEY`, `AI_API_BASE_URL`, and `AI_MODEL` for an OpenAI-compatible vision/chat API. This is required for video processing; videos with audio also require the provider's `/audio/transcriptions` endpoint. Processing fails explicitly if the AI provider is not configured or returns an unusable edit plan.

Health endpoints: `/health/live` and `/health/ready`.

## Local development

Install the root Python dependencies with `uv sync`, then from the service directory run migrations and start the API/worker:

```sh
uv run --project ../.. alembic upgrade head
uv run --project ../.. uvicorn app.main:app --reload --app-dir .
uv run --project ../.. arq app.workers.settings.WorkerSettings
uv run --project ../.. pytest
```

PostgreSQL and Redis must be reachable at the `DATABASE_URL` and `REDIS_URL` values. The Docker Compose stack is the quickest complete local setup.
Set `DEBUG_AI_ARTIFACTS=true` in the service `.env` during development to write `segments.json`, `analysis.json`, and `edit-plan.json` into each job work directory. Keep it disabled in production.

## Data and operational notes

- PostgreSQL migrations are managed by Alembic. Back up PostgreSQL and the shared media volume.
- Job and media records are retained; add a retention policy appropriate to the shop before onboarding real customer footage.
- The included filesystem store is for a single-host MVP. Production deployments with multiple API/worker replicas should replace it with durable object storage and keep `PUBLIC_MEDIA_BASE_URL` publicly reachable.
- `MAX_VIDEO_SIZE_MB` defaults to 20 MB to stay within the standard hosted Telegram Bot API download limit. Larger inbound videos require a supported Telegram Bot API deployment and corresponding configuration. The processed preview is capped at `MAX_OUTPUT_SIZE_MB` (48 MB by default) to fit normal Telegram bot uploads.
- Instagram publishing uses the official Graph API container → processing status → `media_publish` flow. Publishing fails explicitly when account credentials, the public URL, or a Graph API permission is missing.
- A timeout after Meta accepts a publish request can be ambiguous. Check the Instagram account before manually retrying such a job to avoid duplicate posts.
- The Telegram user allowlist is mandatory so an arbitrary bot user cannot approve posts to the shop’s Instagram account. Keep the webhook secret enabled and use HTTPS.
- Persian text is right-to-left in bot messages and subtitle files. The container includes Noto Arabic-capable fonts; set `FFMPEG_FONT_NAME` to a font installed on the host.

## Tests

```sh
uv run --project ../.. pytest
```

Tests cover storyboard validation and repair, timestamped frame requests, multi-clip FFmpeg rendering, Persian captions, video quality checks, approval decisions, and Instagram publishing request behavior. They do not call live Telegram, Meta, AI, PostgreSQL, or Redis services.