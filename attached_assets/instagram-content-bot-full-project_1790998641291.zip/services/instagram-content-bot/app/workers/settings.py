from arq.connections import RedisSettings

from app.core.config import get_settings
from app.workers.tasks import (
    collect_post_analytics,
    process_telegram_update,
    publish_approved_reel,
    run_video_pipeline,
    shutdown,
    startup,
)

settings = get_settings()


class WorkerSettings:
    functions = [
        process_telegram_update,
        run_video_pipeline,
        publish_approved_reel,
        collect_post_analytics,
    ]
    redis_settings = (
        RedisSettings.from_dsn(settings.redis_url)
        if settings.redis_url
        else RedisSettings()
    )
    on_startup = startup
    on_shutdown = shutdown
    max_jobs = 2
    job_timeout = 1800
    max_tries = 3