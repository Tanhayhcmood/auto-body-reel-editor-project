import logging
import secrets
import shutil
from pathlib import Path
from uuid import UUID, uuid4

from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import async_sessionmaker

from app.agents.analytics import AnalyticsAgent
from app.agents.approval import ApprovalAgent, ApprovalStateError, decide_approval
from app.agents.contracts import PipelineContext
from app.agents.instagram_publishing import InstagramPublishingAgent
from app.agents.pipeline import run_content_pipeline
from app.core.config import Settings, get_settings
from app.core.storage import LocalMediaStorage
from app.models import Post, TelegramUpdate, TelegramUser, VideoJob
from app.schemas.telegram import TelegramUpdateSchema
from app.services.instagram_graph import InstagramGraphClient
from app.services.telegram_client import TelegramClient

logger = logging.getLogger(__name__)


async def startup(ctx: dict) -> None:
    from sqlalchemy.ext.asyncio import async_sessionmaker, create_async_engine

    settings = get_settings()
    settings.validate_runtime()
    if not shutil.which("ffmpeg") or not shutil.which("ffprobe"):
        raise RuntimeError("FFmpeg and ffprobe must be installed in the worker image.")
    engine = create_async_engine(settings.database_url, pool_pre_ping=True)
    ctx["settings"] = settings
    ctx["engine"] = engine
    ctx["session_factory"] = async_sessionmaker(engine, expire_on_commit=False)
    ctx["storage"] = LocalMediaStorage(settings.storage_dir)
    await ctx["redis"].ping()


async def shutdown(ctx: dict) -> None:
    await ctx["engine"].dispose()


async def process_telegram_update(ctx: dict, payload: dict) -> None:
    settings: Settings = ctx["settings"]
    update = TelegramUpdateSchema.model_validate(payload)
    if update.callback_query:
        await _handle_approval_callback(ctx, update)
        return
    if not update.message:
        return

    message = update.message
    telegram_user_id = message.from_user.id if message.from_user else message.chat.id
    if settings.allowed_user_ids and telegram_user_id not in settings.allowed_user_ids:
        logger.warning("Ignored message from a Telegram user outside the bot allowlist")
        await TelegramClient(settings).send_message(
            message.chat.id,
            "این ربات خصوصی است و حساب تلگرام شما اجازه استفاده از آن را ندارد.",
        )
        return

    async with ctx["session_factory"]() as session:
        existing = await session.get(TelegramUpdate, update.update_id)
        if existing and existing.processing_status == "completed":
            return
        if not existing:
            existing = TelegramUpdate(
                update_id=update.update_id,
                payload=payload,
                processing_status="queued",
            )
            session.add(existing)
            try:
                await session.flush()
            except IntegrityError:
                await session.rollback()
                return
        user = await session.get(TelegramUser, message.chat.id)
        if not user:
            user = TelegramUser(
                chat_id=message.chat.id,
                telegram_user_id=telegram_user_id,
                username=message.from_user.username if message.from_user else None,
                language_code=message.from_user.language_code if message.from_user else None,
            )
            session.add(user)
        else:
            user.telegram_user_id = telegram_user_id
            if message.from_user:
                user.username = message.from_user.username
                user.language_code = message.from_user.language_code

        video = message.video or (
            message.document
            if message.document and (message.document.mime_type or "").startswith("video/")
            else None
        )
        if not video:
            existing.processing_status = "completed"
            await session.commit()
            await TelegramClient(settings).send_message(
                message.chat.id,
                "سلام! ویدیوی خام تعمیر بدنه خودرو را بفرستید تا ریل آماده شود. "
                "پس از دیدن پیش‌نمایش، خودتان انتشار را تأیید می‌کنید.",
            )
            return

        if video.file_size and video.file_size > settings.max_video_size_mb * 1024 * 1024:
            existing.processing_status = "completed"
            await session.commit()
            await TelegramClient(settings).send_message(
                message.chat.id,
                f"حجم ویدیو بیشتر از سقف {settings.max_video_size_mb} مگابایت است. "
                "لطفاً یک نسخه کم‌حجم‌تر بفرستید.",
            )
            return

        job = None
        if existing.linked_job_id:
            job = await session.get(VideoJob, existing.linked_job_id)
        if not job:
            job_id = uuid4()
            job = VideoJob(
                id=job_id,
                source_update_id=update.update_id,
                chat_id=message.chat.id,
                telegram_user_id=telegram_user_id,
                status="received",
                original_file_key=f"{job_id}/original.mp4",
                media_token=secrets.token_urlsafe(32),
            )
            session.add(job)
            existing.linked_job_id = job.id
        existing.processing_status = "processing"
        await session.commit()
        job_id = job.id
        file_id = video.file_id
        source_key = job.original_file_key
        chat_id = message.chat.id

    storage: LocalMediaStorage = ctx["storage"]
    source_path = storage.resolve(source_key)
    if not source_path.is_file():
        try:
            await TelegramClient(settings).download_file(
                file_id,
                source_path,
                max_bytes=settings.max_video_size_mb * 1024 * 1024,
            )
        except ValueError:
            async with ctx["session_factory"]() as session:
                job = await session.get(VideoJob, job_id)
                stored_update = await session.get(TelegramUpdate, update.update_id)
                if job:
                    job.status = "failed"
                    job.error_message = "Uploaded video exceeds the configured size limit."
                if stored_update:
                    stored_update.processing_status = "completed"
                await session.commit()
            await TelegramClient(settings).send_message(
                chat_id,
                f"حجم ویدیو از سقف {settings.max_video_size_mb} مگابایت بیشتر است. "
                "لطفاً نسخه کم‌حجم‌تری بفرستید.",
            )
            return
    await ctx["redis"].enqueue_job(
        "run_video_pipeline", str(job_id), _job_id=f"pipeline-{job_id}"
    )
    async with ctx["session_factory"]() as session:
        stored_update = await session.get(TelegramUpdate, update.update_id)
        if stored_update:
            stored_update.processing_status = "completed"
            await session.commit()
    logger.info("Queued video processing job %s for chat %s", job_id, chat_id)


async def run_video_pipeline(ctx: dict, job_id: str) -> None:
    job_uuid = UUID(job_id)
    async with ctx["session_factory"]() as session:
        job = await session.get(VideoJob, job_uuid)
        if not job:
            logger.warning("Video job %s is missing; skipping pipeline", job_id)
            return
        if job.status in {
            "awaiting_approval",
            "approved",
            "publishing",
            "published",
            "rejected",
        }:
            return
        if job.status != "received":
            logger.warning("Video job %s is already in state %s", job_id, job.status)
            return
    telegram = TelegramClient(ctx["settings"])
    await run_content_pipeline(
        job,
        ctx["session_factory"],
        ctx["storage"],
        telegram,
        ctx["settings"],
    )


async def _handle_approval_callback(ctx: dict, update: TelegramUpdateSchema) -> None:
    callback = update.callback_query
    if not callback:
        return
    telegram = TelegramClient(ctx["settings"])
    payload = callback.data or ""
    try:
        action, raw_job_id = payload.split(":", 1)
        job_id = UUID(raw_job_id)
        next_status = "approved" if action == "approve" else "rejected"
        if action not in {"approve", "reject"}:
            raise ValueError
    except ValueError:
        await telegram.answer_callback_query(callback.id, "درخواست معتبر نیست.")
        return

    settings: Settings = ctx["settings"]
    if settings.allowed_user_ids and callback.from_user.id not in settings.allowed_user_ids:
        await telegram.answer_callback_query(callback.id, "اجازه انجام این کار را ندارید.")
        return

    async with ctx["session_factory"]() as session:
        event = await session.get(TelegramUpdate, update.update_id)
        if not event:
            event = TelegramUpdate(
                update_id=update.update_id,
                payload=update.model_dump(mode="json", by_alias=True, exclude_none=True),
                processing_status="processing",
            )
            session.add(event)
            try:
                await session.flush()
            except IntegrityError:
                await session.rollback()
                return
        job = await session.scalar(
            select(VideoJob).where(VideoJob.id == job_id).with_for_update()
        )
        if not job:
            event.processing_status = "completed"
            await session.commit()
            await telegram.answer_callback_query(callback.id, "این پیش‌نمایش پیدا نشد.")
            return
        if job.telegram_user_id != callback.from_user.id:
            event.processing_status = "completed"
            await session.commit()
            await telegram.answer_callback_query(callback.id, "فقط فرستنده ویدیو می‌تواند تصمیم بگیرد.")
            return
        if callback.message and callback.message.chat.id != job.chat_id:
            event.processing_status = "completed"
            await session.commit()
            await telegram.answer_callback_query(callback.id, "این پیش‌نمایش برای این گفتگو نیست.")
            return
        already_approved = job.status == "approved" and action == "approve"
        if not already_approved:
            try:
                job.status = decide_approval(job.status, action)
            except ApprovalStateError:
                event.processing_status = "completed"
                await session.commit()
                await telegram.answer_callback_query(callback.id, "این ویدیو قبلاً بررسی شده است.")
                return
        event.processing_status = "completed"
        await session.commit()

    if next_status == "approved":
        await telegram.answer_callback_query(callback.id, "تأیید شد؛ در حال انتشار.")
        await ctx["redis"].enqueue_job(
            "publish_approved_reel",
            str(job_id),
            _job_id=f"publish-{job_id}",
        )
    else:
        await telegram.answer_callback_query(callback.id, "ویدیو رد شد و منتشر نمی‌شود.")
        await telegram.send_message(
            callback.message.chat.id if callback.message else job.chat_id,
            "ویدیو رد شد؛ چیزی در اینستاگرام منتشر نمی‌شود.",
        )


async def publish_approved_reel(ctx: dict, job_id: str) -> None:
    job_uuid = UUID(job_id)
    async with ctx["session_factory"]() as session:
        job = await session.scalar(
            select(VideoJob).where(VideoJob.id == job_uuid).with_for_update()
        )
        if not job or job.status == "published":
            return
        if job.status == "publishing":
            post = await session.scalar(select(Post).where(Post.job_id == job_uuid))
            if post and post.creation_container_id:
                post.status = "reconciliation_required"
                job.status = "publish_attention"
                await session.commit()
                await TelegramClient(ctx["settings"]).send_message(
                    job.chat_id,
                    "وضعیت انتشار از طرف متا قطعی نیست. پیش از تلاش دوباره، "
                    "حساب اینستاگرام را بررسی کنید تا پست تکراری ساخته نشود.",
                )
                return
            if not post:
                return
            post.status = "creating_container"
        elif job.status == "approved":
            post = None
        else:
            return
        if not job.final_video_key or not job.cover_file_key or not job.caption:
            job.status = "failed"
            job.error_message = "Approved post is missing its generated assets."
            await session.commit()
            return
        if not post:
            post = await session.scalar(select(Post).where(Post.job_id == job_uuid))
            if post:
                logger.warning("Post record already exists for job %s; not publishing again", job_id)
                return
            post = Post(job_id=job_uuid, caption=job.caption, status="creating_container")
            session.add(post)
            job.status = "publishing"
            job.worker_publish_attempted = True
        await session.commit()
        post_id = post.id
        chat_id = job.chat_id
        context = PipelineContext(
            job_id=job_uuid,
            chat_id=job.chat_id,
            telegram_user_id=job.telegram_user_id,
            media_token=job.media_token,
            source_key=job.original_file_key or "",
            work_dir=ctx["storage"].resolve(f"{job_uuid}/work"),
            settings=ctx["settings"],
            storage=ctx["storage"],
            final_video_key=job.final_video_key,
            cover_file_key=job.cover_file_key,
            caption=job.caption,
            hook=job.hook or "",
        )

    async def persist_container(container_id: str) -> None:
        async with ctx["session_factory"]() as session:
            saved_post = await session.get(Post, post_id)
            if saved_post:
                saved_post.creation_container_id = container_id
                saved_post.status = "processing_container"
                await session.commit()

    context.on_container_created = persist_container
    try:
        publisher = InstagramPublishingAgent(InstagramGraphClient(ctx["settings"]))
        result = await publisher.run(context)
        async with ctx["session_factory"]() as session:
            job = await session.get(VideoJob, job_uuid)
            post = await session.get(Post, post_id)
            if not job or not post:
                raise RuntimeError("Publish state disappeared before it could be saved.")
            job.status = "published"
            job.instagram_media_id = result["instagram_media_id"]
            post.instagram_media_id = result["instagram_media_id"]
            post.status = "published"
            post.analytics_status = "pending"
            await session.commit()
        await TelegramClient(ctx["settings"]).send_message(
            chat_id, "ریلز با موفقیت در حساب اینستاگرام منتشر شد."
        )
        try:
            await ctx["redis"].enqueue_job(
                "collect_post_analytics",
                str(post_id),
                _job_id=f"analytics-{post_id}",
            )
        except Exception:
            logger.exception("Could not enqueue analytics collection for post %s", post_id)
    except Exception as error:
        logger.exception("Instagram publish failed for video job %s", job_id)
        async with ctx["session_factory"]() as session:
            job = await session.get(VideoJob, job_uuid)
            post = await session.get(Post, post_id)
            if job:
                job.status = "publish_attention" if post and post.creation_container_id else "failed"
                job.error_message = str(error)[:2000]
            if post:
                post.status = (
                    "reconciliation_required"
                    if post.creation_container_id
                    else "failed"
                )
            await session.commit()
        await TelegramClient(ctx["settings"]).send_message(
            chat_id,
            "انتشار ریل کامل نشد. اگر وضعیت مبهم است، قبل از تلاش دوباره "
            "حساب اینستاگرام را بررسی کنید.",
        )
        raise


async def collect_post_analytics(ctx: dict, post_id: str) -> None:
    post_uuid = UUID(post_id)
    try:
        result = await AnalyticsAgent(
            ctx["settings"], ctx["session_factory"]
        ).run(post_uuid)
        logger.info("Analytics collected for post %s: %s", post_id, result)
    except Exception as error:
        logger.exception("Analytics collection failed for post %s", post_id)
        async with ctx["session_factory"]() as session:
            post = await session.get(Post, post_uuid)
            if post:
                post.analytics_status = "unavailable"
                await session.commit()
