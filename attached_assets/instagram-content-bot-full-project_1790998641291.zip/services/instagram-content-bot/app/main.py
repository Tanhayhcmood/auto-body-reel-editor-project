import logging
from contextlib import asynccontextmanager

from arq.connections import create_pool, RedisSettings
from fastapi import FastAPI
from redis.asyncio import Redis
from sqlalchemy.ext.asyncio import async_sessionmaker, create_async_engine

from app.api.health import router as health_router
from app.api.media import router as media_router
from app.api.telegram import router as telegram_router
from app.core.config import get_settings


@asynccontextmanager
async def lifespan(app: FastAPI):
    settings = get_settings()
    settings.validate_runtime()
    engine = create_async_engine(settings.database_url, pool_pre_ping=True)
    redis = Redis.from_url(settings.redis_url)
    arq_pool = None
    try:
        await redis.ping()
        arq_pool = await create_pool(RedisSettings.from_dsn(settings.redis_url))
        app.state.settings = settings
        app.state.session_factory = async_sessionmaker(engine, expire_on_commit=False)
        app.state.redis = redis
        app.state.arq_pool = arq_pool
        yield
    finally:
        if arq_pool:
            await arq_pool.aclose()
        await redis.aclose()
        await engine.dispose()


def create_app() -> FastAPI:
    logging.basicConfig(
        level=get_settings().log_level.upper(),
        format="%(asctime)s %(levelname)s %(name)s %(message)s",
    )
    application = FastAPI(
        title="Auto Repair Reel Bot",
        description="Persian Telegram-to-Instagram Reel automation with human approval.",
        version="0.1.0",
        lifespan=lifespan,
    )
    application.include_router(health_router)
    application.include_router(telegram_router)
    application.include_router(media_router)
    return application


app = create_app()