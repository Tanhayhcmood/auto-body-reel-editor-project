import asyncio
import subprocess
from pathlib import Path

from app.agents.contracts import PipelineContext
from app.agents.video_analysis import _run
from app.agents.video_editing import portrait_filter


class CoverAgent:
    name = "cover"

    async def run(self, context: PipelineContext) -> dict[str, str | float]:
        if context.reel_edit_plan:
            hook_clip = context.reel_edit_plan.clips[0]
            cover_time = hook_clip.start + (hook_clip.end - hook_clip.start) / 2
        else:
            cover_time = float(context.strategy["start_seconds"]) + min(
                2.0, float(context.strategy["duration_seconds"]) / 2
            )
        context.cover_path = context.work_dir / "cover.jpg"

        def render() -> None:
            _run(
                [
                    "ffmpeg",
                    "-hide_banner",
                    "-loglevel",
                    "error",
                    "-y",
                    "-ss",
                    str(cover_time),
                    "-i",
                    str(context.source_path),
                    "-frames:v",
                    "1",
                    "-filter_complex",
                    portrait_filter(context),
                    "-map",
                    "[reel]",
                    "-q:v",
                    "2",
                    str(context.cover_path),
                ],
                timeout=120,
            )

        await asyncio.to_thread(render)
        if not context.cover_path.is_file():
            raise RuntimeError("FFmpeg did not create the Reel cover.")
        return {"file": str(context.cover_path), "source_time_seconds": cover_time}