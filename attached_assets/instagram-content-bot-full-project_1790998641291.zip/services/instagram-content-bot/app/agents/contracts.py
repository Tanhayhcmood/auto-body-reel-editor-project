from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from collections.abc import Awaitable, Callable
from typing import TYPE_CHECKING, Any, Protocol
from uuid import UUID

from app.core.config import Settings
from app.core.storage import LocalMediaStorage

if TYPE_CHECKING:
    from app.agents.storyboard import ReelEditPlan


@dataclass
class PipelineContext:
    job_id: UUID
    chat_id: int
    telegram_user_id: int
    media_token: str
    source_key: str
    work_dir: Path
    settings: Settings
    storage: LocalMediaStorage
    shop_name: str | None = None
    learned_hook: str | None = None
    source_path: Path = field(init=False)
    analysis: dict[str, Any] = field(default_factory=dict)
    strategy: dict[str, Any] = field(default_factory=dict)
    reel_edit_plan: ReelEditPlan | None = None
    transcript_segments: list[dict[str, Any]] = field(default_factory=list)
    hook: str = ""
    caption: str = ""
    cta: str = ""
    final_video_path: Path | None = None
    cover_path: Path | None = None
    subtitles_path: Path | None = None
    final_video_key: str | None = None
    cover_file_key: str | None = None
    on_container_created: Callable[[str], Awaitable[None]] | None = None

    def __post_init__(self) -> None:
        self.source_path = self.storage.resolve(self.source_key)
        self.work_dir.mkdir(parents=True, exist_ok=True)


class Agent(Protocol):
    name: str

    async def run(self, context: PipelineContext) -> dict[str, Any]: ...