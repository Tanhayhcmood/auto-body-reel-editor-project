from app.agents.contracts import PipelineContext


class ContentStrategyAgent:
    name = "content_strategy"

    async def run(self, context: PipelineContext) -> dict[str, float | str]:
        analysis = context.analysis
        duration = float(analysis["duration_seconds"])
        maximum = float(context.settings.max_reel_duration_seconds)
        visual_notes = analysis.get("visual_notes", {})
        proposed_start = visual_notes.get("start_seconds")
        proposed_end = visual_notes.get("end_seconds")

        if proposed_start is not None and proposed_end is not None:
            start = max(0.0, min(float(proposed_start), max(duration - 1, 0)))
            end = max(start + 1.0, min(float(proposed_end), duration))
            if end - start > maximum:
                end = start + maximum
            if end > duration:
                end = duration
        elif duration <= maximum:
            start, end = 0.0, duration
        else:
            scene_points = [
                float(point)
                for point in analysis.get("scene_change_seconds", [])
                if 0 < float(point) < duration
            ]
            midpoint = scene_points[len(scene_points) // 2] if scene_points else duration / 2
            start = max(0.0, min(midpoint - maximum / 2, duration - maximum))
            end = min(duration, start + maximum)

        context.strategy = {
            "start_seconds": round(start, 3),
            "end_seconds": round(end, 3),
            "duration_seconds": round(end - start, 3),
            "aspect_ratio": "9:16",
            "selection_method": (
                "ai_visual_moments"
                if proposed_start is not None and proposed_end is not None
                else "bounded_scene_heuristic"
            ),
            "scene_changes_in_clip": [
                point
                for point in analysis.get("scene_change_seconds", [])
                if start <= float(point) <= end
            ],
        }
        return context.strategy