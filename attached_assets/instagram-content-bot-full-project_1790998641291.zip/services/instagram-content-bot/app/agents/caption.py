from typing import Any

from app.agents.contracts import PipelineContext
from app.services.ai_provider import OpenAICompatibleProvider


FALLBACK_HOOKS = (
    "از آسیب تا نتیجه‌ای که باید ببینید",
    "این تغییر را از دست ندهید",
    "بازسازی بدنه؛ قدم‌به‌قدم تا نتیجه نهایی",
)


class CaptionAgent:
    name = "caption"

    async def run(self, context: PipelineContext) -> dict[str, str]:
        provider = OpenAICompatibleProvider(context.settings)
        storyboard_hook = context.hook
        storyboard_cta = context.cta
        result: dict[str, Any]
        if provider.enabled:
            result = await provider.generate_caption(
                analysis=context.analysis,
                strategy=context.strategy,
                transcript=" ".join(
                    segment.get("text", "")
                    for segment in context.transcript_segments
                    if segment.get("text")
                ),
                learned_hook=context.learned_hook,
                shop_name=context.shop_name,
            )
            hook = storyboard_hook or str(result["hook"]).strip()
            caption = str(result["caption"]).strip()
            cta = storyboard_cta or str(result["cta"]).strip()
        else:
            index = int(context.job_id.int % len(FALLBACK_HOOKS))
            hook = context.learned_hook or FALLBACK_HOOKS[index]
            shop = f" در {context.shop_name}" if context.shop_name else ""
            caption = (
                f"از بررسی آسیب تا اجرای دقیق صافکاری و رنگ{shop}. "
                "هر مرحله با دقت انجام می‌شود تا خودرو دوباره ظاهر مرتب و یکدستی داشته باشد."
            )
            cta = "برای مشاوره و برآورد هزینه، در دایرکت پیام بدهید."

        if not hook or not caption or not cta:
            raise ValueError("Caption generation returned an empty hook, caption, or CTA.")
        full_caption = f"{caption}\n\n{cta}\n\n#صافکاری #نقاشی_خودرو #تعمیر_بدنه"
        if len(full_caption) > 2200:
            raise ValueError("Generated Instagram caption exceeds the 2,200 character limit.")
        context.hook = hook[:200]
        context.caption = full_caption
        context.cta = cta
        return {
            "hook": context.hook,
            "caption": context.caption,
            "cta": context.cta,
            "mode": "ai" if provider.enabled else "persian_template",
        }