from pathlib import Path

from app.agents.contracts import PipelineContext
from app.agents.video_analysis import probe_video


class QualityControlAgent:
    name = "quality_control"

    async def run(self, context: PipelineContext) -> dict[str, object]:
        if not context.final_video_path or not context.cover_path:
            raise ValueError("A finished video and cover are required for quality checks.")
        if not context.final_video_path.is_file() or not context.cover_path.is_file():
            raise ValueError("The generated video or cover file is missing.")
        video_size = context.final_video_path.stat().st_size
        cover_size = context.cover_path.stat().st_size
        if video_size < 16_000 or cover_size < 1_000:
            raise ValueError("The generated Reel or cover is unexpectedly small.")
        if video_size > context.settings.max_output_size_mb * 1024 * 1024:
            raise ValueError(
                f"The Reel exceeds the {context.settings.max_output_size_mb} MB "
                "Telegram preview limit."
            )

        metadata = await probe_video(context.final_video_path)
        stream = next(
            (item for item in metadata.get("streams", []) if item.get("codec_type") == "video"),
            None,
        )
        if not stream:
            raise ValueError("The output file contains no video stream.")
        width, height = int(stream.get("width", 0)), int(stream.get("height", 0))
        duration = float(metadata.get("format", {}).get("duration", 0))
        ratio = width / height if height else 0
        if width < 720 or height < 1280 or abs(ratio - (9 / 16)) > 0.015:
            raise ValueError(f"Output must be a 9:16 vertical video; got {width}x{height}.")
        if not 1 <= duration <= context.settings.max_reel_duration_seconds + 2:
            raise ValueError(f"Output duration is outside the configured Reel limit: {duration:.1f}s.")
        if Path(context.cover_path).suffix.lower() not in {".jpg", ".jpeg"}:
            raise ValueError("The generated cover must be a JPEG image.")
        return {
            "passed": True,
            "width": width,
            "height": height,
            "duration_seconds": round(duration, 2),
            "video_bytes": video_size,
            "cover_bytes": cover_size,
            "codec": stream.get("codec_name"),
        }