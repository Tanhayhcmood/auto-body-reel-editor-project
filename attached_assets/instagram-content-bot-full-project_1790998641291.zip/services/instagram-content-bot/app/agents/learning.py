from collections import defaultdict
from typing import Any

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

from app.models import AnalyticsSnapshot, LearningInsight, Post, VideoJob


class LearningAgent:
    name = "learning"

    def __init__(self, factory: async_sessionmaker[AsyncSession]):
        self.factory = factory

    async def run(self, telegram_user_id: int) -> dict[str, Any]:
        async with self.factory() as session:
            rows = (
                await session.execute(
                    select(
                        VideoJob.hook,
                        AnalyticsSnapshot.reach,
                        AnalyticsSnapshot.likes,
                        AnalyticsSnapshot.comments,
                        AnalyticsSnapshot.shares,
                        AnalyticsSnapshot.saves,
                    )
                    .join(Post, Post.job_id == VideoJob.id)
                    .join(AnalyticsSnapshot, AnalyticsSnapshot.post_id == Post.id)
                    .where(
                        VideoJob.telegram_user_id == telegram_user_id,
                        AnalyticsSnapshot.reach.is_not(None),
                        AnalyticsSnapshot.reach > 0,
                    )
                    .order_by(AnalyticsSnapshot.collected_at.desc())
                    .limit(100)
                )
            ).all()
            grouped: dict[str, list[float]] = defaultdict(list)
            for hook, reach, likes, comments, shares, saves in rows:
                key = " ".join((hook or "").split()[:6])
                if not key or not reach:
                    continue
                interactions = sum(
                    int(value or 0) for value in (likes, comments, shares, saves)
                )
                grouped[key].append(interactions / reach)
            ranked = sorted(
                (
                    (hook, sum(rates) / len(rates), len(rates))
                    for hook, rates in grouped.items()
                ),
                key=lambda item: (item[1], item[2]),
                reverse=True,
            )
            result: dict[str, Any] = {
                "sample_size": len(rows),
                "recommended_hook": ranked[0][0] if ranked and len(rows) >= 3 else None,
                "mean_interaction_rate": round(ranked[0][1], 4)
                if ranked and len(rows) >= 3
                else None,
            }
            insight = await session.scalar(
                select(LearningInsight).where(
                    LearningInsight.telegram_user_id == telegram_user_id,
                    LearningInsight.insight_type == "hook_performance",
                )
            )
            if insight:
                insight.value = result
            else:
                session.add(
                    LearningInsight(
                        telegram_user_id=telegram_user_id,
                        insight_type="hook_performance",
                        value=result,
                    )
                )
            await session.commit()
            return result