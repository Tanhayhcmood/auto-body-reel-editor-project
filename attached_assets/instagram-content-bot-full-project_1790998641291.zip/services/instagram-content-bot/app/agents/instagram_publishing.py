from app.agents.contracts import PipelineContext
from app.core.storage import LocalMediaStorage
from app.services.instagram_graph import InstagramGraphClient


class InstagramPublishingAgent:
    name = "instagram_publishing"

    def __init__(self, client: InstagramGraphClient):
        self.client = client

    async def run(self, context: PipelineContext) -> dict[str, str]:
        if not context.final_video_key or not context.cover_file_key:
            raise ValueError("The approved Reel is missing its media files.")
        storage = LocalMediaStorage(context.settings.storage_dir)
        video_url = storage.public_url(
            context.settings.public_media_base_url,
            str(context.job_id),
            context.media_token,
            "video",
        )
        cover_url = storage.public_url(
            context.settings.public_media_base_url,
            str(context.job_id),
            context.media_token,
            "cover",
        )
        container_id = await self.client.create_reel_container(
            video_url, cover_url, context.caption
        )
        if context.on_container_created:
            await context.on_container_created(container_id)
        await self.client.wait_until_ready(container_id)
        published = await self.client.publish_container(container_id)
        return {
            "container_id": container_id,
            "instagram_media_id": published["media_id"],
        }