from typing import Annotated, Any, Literal, Self

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    StringConstraints,
    ValidationError,
    ValidationInfo,
    model_validator,
)

from app.agents.contracts import PipelineContext
from app.services.ai_provider import OpenAICompatibleProvider
from app.services.video_segmentation import write_debug_json


NonEmptyText = Annotated[str, StringConstraints(strip_whitespace=True, min_length=1)]
ClipPurpose = Literal[
    "hook",
    "before",
    "repair_process",
    "satisfying_detail",
    "tools_action",
    "close_up_detail",
    "final_result",
    "vehicle_reveal",
    "painting",
    "sanding",
    "polishing",
    "dent_repair",
    "other",
]


class ReelClip(BaseModel):
    model_config = ConfigDict(extra="forbid")

    start: float = Field(ge=0, allow_inf_nan=False)
    end: float = Field(gt=0, allow_inf_nan=False)
    purpose: ClipPurpose
    reason: NonEmptyText
    zoom: bool = False
    reframe_x: float = Field(default=0.5, ge=0, le=1, allow_inf_nan=False)
    reframe_y: float = Field(default=0.5, ge=0, le=1, allow_inf_nan=False)

    @model_validator(mode="after")
    def require_positive_duration(self) -> Self:
        if self.end <= self.start:
            raise ValueError("Clip end must be greater than clip start.")
        return self


class ReelHookConcept(BaseModel):
    model_config = ConfigDict(extra="forbid")

    start: float = Field(ge=0, allow_inf_nan=False)
    end: float = Field(gt=0, allow_inf_nan=False)
    text: NonEmptyText
    reason: NonEmptyText

    @model_validator(mode="after")
    def require_positive_duration(self) -> Self:
        if self.end <= self.start:
            raise ValueError("Hook end must be greater than hook start.")
        return self


class ReelOverlayText(BaseModel):
    model_config = ConfigDict(extra="forbid")

    start: float = Field(ge=0, allow_inf_nan=False)
    end: float = Field(gt=0, allow_inf_nan=False)
    text: NonEmptyText

    @model_validator(mode="after")
    def require_positive_duration(self) -> Self:
        if self.end <= self.start:
            raise ValueError("Overlay end must be greater than overlay start.")
        return self


class ReelEditPlan(BaseModel):
    """A validated, source-timestamped editorial decision made by the AI."""

    model_config = ConfigDict(extra="forbid")

    concept: NonEmptyText
    hook_concepts: list[ReelHookConcept] = Field(min_length=5, max_length=5)
    selected_hook: ReelHookConcept
    clips: list[ReelClip] = Field(min_length=1, max_length=24)
    target_duration: float = Field(gt=0, allow_inf_nan=False)
    overlay_text: list[ReelOverlayText] = Field(default_factory=list, max_length=12)
    cta: NonEmptyText

    @property
    def hook(self) -> ReelHookConcept:
        """Compatibility for unchanged caption, cover, and subtitle consumers."""
        return self.selected_hook

    @model_validator(mode="after")
    def validate_editorial_plan(self, info: ValidationInfo) -> Self:
        concept_texts = [hook.text.casefold() for hook in self.hook_concepts]
        if len(set(concept_texts)) != 5:
            raise ValueError("The plan must contain five distinct hook concepts.")
        if not any(
            concept.text == self.selected_hook.text
            and abs(concept.start - self.selected_hook.start) <= 0.01
            and abs(concept.end - self.selected_hook.end) <= 0.01
            for concept in self.hook_concepts
        ):
            raise ValueError("The selected hook must match one of the five concepts.")
        first_clip = self.clips[0]
        if first_clip.purpose != "hook":
            raise ValueError("The first clip must be the selected hook.")
        if (
            abs(first_clip.start - self.selected_hook.start) > 0.01
            or abs(first_clip.end - self.selected_hook.end) > 0.01
        ):
            raise ValueError("Hook timestamps must match the first hook clip.")

        context = info.context or {}
        source_duration = context.get("video_duration")
        max_reel_duration = context.get("max_reel_duration")
        if source_duration is not None:
            for clip in self.clips:
                if clip.end > source_duration:
                    raise ValueError(
                        f"Clip timestamps must be within the {source_duration:.3f}s source video."
                    )
            if any(hook.end > source_duration for hook in self.hook_concepts):
                raise ValueError("Hook concept timestamps exceed the source video duration.")
            for overlay in self.overlay_text:
                if overlay.end > source_duration:
                    raise ValueError("Overlay timestamps exceed the source video duration.")
        source_segments = context.get("source_segments")
        if source_segments is not None:
            segment_ranges: list[tuple[float, float]] = []
            for segment in source_segments:
                try:
                    start = float(segment["start"])
                    end = float(segment["end"])
                except (KeyError, TypeError, ValueError) as error:
                    raise ValueError(
                        "Analyzed source segments must have numeric start and end timestamps."
                    ) from error
                if start < 0 or end <= start:
                    raise ValueError("Analyzed source segment ranges must be positive.")
                segment_ranges.append((start, end))

            def fits_analyzed_segment(start: float, end: float) -> bool:
                return any(
                    start >= segment_start - 0.01
                    and end <= segment_end + 0.01
                    for segment_start, segment_end in segment_ranges
                )

            if not all(
                fits_analyzed_segment(hook.start, hook.end)
                for hook in self.hook_concepts
            ):
                raise ValueError(
                    "Every hook concept must fit within one analyzed source segment."
                )
            if not all(
                fits_analyzed_segment(clip.start, clip.end) for clip in self.clips
            ):
                raise ValueError(
                    "Every selected clip must fit within one analyzed source segment."
                )
        total_duration = sum(clip.end - clip.start for clip in self.clips)
        if abs(total_duration - self.target_duration) > max(
            0.25, total_duration * 0.03
        ):
            raise ValueError(
                "Target duration must be close to the sum of selected clip durations."
            )
        if max_reel_duration is not None:
            if self.target_duration > max_reel_duration:
                raise ValueError("Target duration exceeds the configured Reel limit.")
            if total_duration > max_reel_duration:
                raise ValueError("Selected clips exceed the configured Reel limit.")
        return self

    @classmethod
    def from_ai_response(
        cls,
        response: dict[str, Any],
        *,
        video_duration: float,
        max_reel_duration: float,
        source_segments: list[dict[str, Any]] | None = None,
    ) -> Self:
        return cls.model_validate(
            response,
            context={
                "video_duration": video_duration,
                "max_reel_duration": max_reel_duration,
                "source_segments": source_segments,
            },
        )


class StoryboardAgent:
    name = "storyboard"

    async def run(self, context: PipelineContext) -> dict[str, Any]:
        provider = OpenAICompatibleProvider(context.settings)
        if not provider.enabled:
            raise RuntimeError(
                "AI_API_KEY is required to create a Reel storyboard; "
                "the pipeline will not substitute a template or heuristic edit."
            )

        duration = float(context.analysis["duration_seconds"])
        maximum = float(context.settings.max_reel_duration_seconds)
        source_segments = context.analysis.get("segments")
        if not isinstance(source_segments, list) or not source_segments:
            raise RuntimeError(
                "AI segment analysis is required before creating a Reel storyboard."
            )
        transcript = " ".join(
            str(segment.get("text", "")).strip()
            for segment in context.transcript_segments
            if segment.get("text")
        )
        response = await provider.generate_reel_edit_plan(
            duration_seconds=duration,
            max_duration_seconds=maximum,
            analysis=context.analysis,
            transcript=transcript,
        )
        try:
            plan = ReelEditPlan.from_ai_response(
                response,
                video_duration=duration,
                max_reel_duration=maximum,
                source_segments=source_segments,
            )
        except ValidationError as first_error:
            repaired_response = await provider.repair_reel_edit_plan(
                duration_seconds=duration,
                max_duration_seconds=maximum,
                analysis=context.analysis,
                transcript=transcript,
                invalid_plan=response,
                validation_errors=str(first_error)[:4000],
            )
            try:
                plan = ReelEditPlan.from_ai_response(
                    repaired_response,
                    video_duration=duration,
                    max_reel_duration=maximum,
                    source_segments=source_segments,
                )
            except ValidationError as final_error:
                raise RuntimeError(
                    "AI returned an invalid Reel edit plan after one repair attempt: "
                    f"{final_error}"
                ) from final_error

        context.reel_edit_plan = plan
        context.hook = plan.selected_hook.text
        context.cta = plan.cta
        first_clip = plan.clips[0]
        context.strategy = {
            **plan.model_dump(mode="json"),
            "start_seconds": first_clip.start,
            "end_seconds": first_clip.end,
            "duration_seconds": sum(clip.end - clip.start for clip in plan.clips),
            "aspect_ratio": "9:16",
            "selection_method": "ai_storyboard",
        }
        write_debug_json(
            context.work_dir,
            "edit-plan.json",
            plan.model_dump(mode="json"),
            enabled=context.settings.debug_ai_artifacts,
        )
        return context.strategy