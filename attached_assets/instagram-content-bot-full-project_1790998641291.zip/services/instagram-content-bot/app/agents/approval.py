from app.agents.contracts import PipelineContext
from app.services.telegram_client import TelegramClient


class ApprovalStateError(ValueError):
    pass


def decide_approval(current_status: str, action: str) -> str:
    if current_status != "awaiting_approval":
        raise ApprovalStateError("This video is no longer waiting for approval.")
    if action == "approve":
        return "approved"
    if action == "reject":
        return "rejected"
    raise ApprovalStateError("Unknown approval action.")


class ApprovalAgent:
    name = "approval"

    def __init__(self, telegram: TelegramClient):
        self.telegram = telegram

    async def run(self, context: PipelineContext) -> dict[str, str]:
        if not context.final_video_path or not context.cover_path:
            raise ValueError("Cannot send an incomplete video for approval.")
        keyboard = {
            "inline_keyboard": [
                [
                    {
                        "text": "تأیید و انتشار",
                        "callback_data": f"approve:{context.job_id}",
                    },
                    {
                        "text": "رد و توقف",
                        "callback_data": f"reject:{context.job_id}",
                    },
                ]
            ]
        }
        await self.telegram.send_video(
            context.chat_id,
            context.final_video_path,
            f"پیش‌نمایش ریل: {context.hook}",
            reply_markup=keyboard,
        )
        await self.telegram.send_photo(
            context.chat_id, context.cover_path, "کاور پیشنهادی ریل"
        )
        await self.telegram.send_message(
            context.chat_id,
            f"کپشن پیشنهادی:\n\n{context.caption}\n\n"
            "برای انتشار، دکمه تأیید را روی ویدیو بزنید.",
        )
        return {"sent_to_chat_id": str(context.chat_id), "approval_required": "true"}