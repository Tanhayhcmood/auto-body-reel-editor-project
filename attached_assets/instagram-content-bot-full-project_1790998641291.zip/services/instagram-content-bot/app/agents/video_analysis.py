import asyncio
import json
import subprocess
from pathlib import Path
from typing import Any

from app.agents.contracts import PipelineContext
from app.services.ai_provider import OpenAICompatibleProvider
from app.services.video_segmentation import (
    create_video_segments,
    validate_segment_analyses,
    write_debug_json,
)


def _run(command: list[str], timeout: int = 240) -> subprocess.CompletedProcess[str]:
    result = subprocess.run(
        command,
        capture_output=True,
        text=True,
        timeout=timeout,
        check=False,
    )
    if result.returncode:
        raise RuntimeError(
            f"{Path(command[0]).name} failed: {(result.stderr or result.stdout)[-1000:]}"
        )
    return result


async def probe_video(path: Path) -> dict[str, Any]:
    def probe() -> dict[str, Any]:
        output = _run(
            [
                "ffprobe",
                "-v",
                "error",
                "-show_streams",
                "-show_format",
                "-of",
                "json",
                str(path),
            ],
            timeout=60,
        )
        return json.loads(output.stdout)

    return await asyncio.to_thread(probe)


class VideoAnalysisAgent:
    name = "video_analysis"

    async def run(self, context: PipelineContext) -> dict[str, Any]:
        metadata = await probe_video(context.source_path)
        video_stream = next(
            (stream for stream in metadata.get("streams", []) if stream.get("codec_type") == "video"),
            None,
        )
        if not video_stream:
            raise ValueError("The uploaded file does not contain a video stream.")
        duration = float(metadata.get("format", {}).get("duration", 0))
        if duration <= 0:
            raise ValueError("The uploaded video has no measurable duration.")

        audio_streams = [
            stream
            for stream in metadata.get("streams", [])
            if stream.get("codec_type") == "audio"
        ]
        provider = OpenAICompatibleProvider(context.settings)
        if not provider.enabled:
            raise RuntimeError(
                "AI_API_KEY is required to analyze the uploaded video; "
                "no local or template-based edit plan will be used."
            )

        scene_changes, segments = await create_video_segments(
            context.source_path, duration, context.work_dir
        )
        write_debug_json(
            context.work_dir,
            "segments.json",
            [segment.model_dump(mode="json") for segment in segments],
            enabled=context.settings.debug_ai_artifacts,
        )
        raw_analyses = await provider.analyze_segments(segments)
        segment_analyses = validate_segment_analyses(raw_analyses, segments)
        segment_data = [
            segment.model_dump(mode="json") for segment in segment_analyses
        ]
        base_analysis: dict[str, Any] = {
            "duration_seconds": round(duration, 3),
            "width": int(video_stream.get("width", 0)),
            "height": int(video_stream.get("height", 0)),
            "has_audio": bool(audio_streams),
            "scene_change_seconds": scene_changes,
            "segments": segment_data,
            "model_mode": "ai_segment_vision",
        }
        write_debug_json(
            context.work_dir,
            "analysis.json",
            base_analysis,
            enabled=context.settings.debug_ai_artifacts,
        )

        transcript_segments: list[dict[str, Any]] = []
        transcription_status = "no_audio"
        if audio_streams:
            transcript_segments = await provider.transcribe(context.source_path)
            transcription_status = "transcribed" if transcript_segments else "no_speech"
        context.transcript_segments = transcript_segments
        context.analysis = {
            **base_analysis,
            "transcription_status": transcription_status,
            "transcript_segments": transcript_segments,
            "visual_notes": {
                "summary": " ".join(item["summary"] for item in segment_data),
                "segments": segment_data,
            },
        }
        write_debug_json(
            context.work_dir,
            "analysis.json",
            context.analysis,
            enabled=context.settings.debug_ai_artifacts,
        )
        return context.analysis