import asyncio
import subprocess
from pathlib import Path

from app.agents.contracts import PipelineContext
from app.agents.storyboard import ReelEditPlan


def portrait_filter(context: PipelineContext) -> str:
    subtitle_path = _escape_filter_path(context.subtitles_path)
    font_name = context.settings.ffmpeg_font_name.replace("'", "")
    return (
        "[0:v:0]scale=1080:1920:force_original_aspect_ratio=increase,"
        "crop=1080:1920,setsar=1,"
        f"subtitles=filename='{subtitle_path}':force_style='FontName={font_name}'[reel]"
    )


def _escape_filter_path(path: Path | None) -> str:
    if path is None:
        raise ValueError("A subtitle file is required for Reel rendering.")
    return (
        str(path)
        .replace("\\", "\\\\")
        .replace(":", r"\:")
        .replace("'", r"\'")
    )


def ass_time(seconds: float) -> str:
    total_centiseconds = max(0, round(seconds * 100))
    hours, remainder = divmod(total_centiseconds, 360_000)
    minutes, remainder = divmod(remainder, 6_000)
    whole_seconds, centiseconds = divmod(remainder, 100)
    return f"{hours}:{minutes:02d}:{whole_seconds:02d}.{centiseconds:02d}"


def escape_ass(text: str) -> str:
    return (
        text.replace("\\", "\\\\")
        .replace("{", "\\{")
        .replace("}", "\\}")
        .replace("\r", "")
        .replace("\n", r"\N")
    )


def build_ass(context: PipelineContext) -> str:
    plan = context.reel_edit_plan
    if not isinstance(plan, ReelEditPlan):
        raise ValueError("A validated AI ReelEditPlan is required for editing.")
    total_duration = sum(clip.end - clip.start for clip in plan.clips)
    lines = [
        "[Script Info]",
        "ScriptType: v4.00+",
        "PlayResX: 1080",
        "PlayResY: 1920",
        "WrapStyle: 2",
        "ScaledBorderAndShadow: yes",
        "",
        "[V4+ Styles]",
        "Format: Name,Fontname,Fontsize,PrimaryColour,SecondaryColour,OutlineColour,BackColour,Bold,Italic,Underline,StrikeOut,ScaleX,ScaleY,Spacing,Angle,BorderStyle,Outline,Shadow,Alignment,MarginL,MarginR,MarginV,Encoding",
        f"Style: Default,{context.settings.ffmpeg_font_name},56,&H00FFFFFF,&H000000FF,&H00111111,&H80000000,0,0,0,0,100,100,0,0,1,3,1,2,72,72,150,1",
        f"Style: Hook,{context.settings.ffmpeg_font_name},68,&H00FFFFFF,&H000000FF,&H00111111,&H90000000,1,0,0,0,100,100,0,0,1,4,1,8,80,80,150,1",
        "",
        "[Events]",
        "Format: Layer,Start,End,Style,Name,MarginL,MarginR,MarginV,Effect,Text",
        f"Dialogue: 1,{ass_time(0)},{ass_time(min(3, plan.clips[0].end - plan.clips[0].start))},Hook,,0,0,0,,{escape_ass(plan.hook.text)}",
    ]
    timeline_start = 0.0
    for clip in plan.clips:
        clip_duration = clip.end - clip.start
        for segment in context.transcript_segments:
            try:
                source_start = float(segment["start"])
                source_end = float(segment["end"])
            except (KeyError, TypeError, ValueError):
                continue
            start = timeline_start + max(0.0, source_start - clip.start)
            finish = timeline_start + min(clip_duration, source_end - clip.start)
            text = str(segment.get("text", "")).strip()
            if finish > start and text:
                lines.append(
                    f"Dialogue: 0,{ass_time(start)},{ass_time(finish)},Default,,0,0,0,,{escape_ass(text)}"
                )
        for overlay in plan.overlay_text:
            start = timeline_start + max(0.0, overlay.start - clip.start)
            finish = timeline_start + min(clip_duration, overlay.end - clip.start)
            if finish > start:
                lines.append(
                    f"Dialogue: 0,{ass_time(start)},{ass_time(finish)},Default,,0,0,0,,{escape_ass(overlay.text)}"
                )
        timeline_start += clip_duration

    cta_start = max(0.0, total_duration - min(3.0, total_duration))
    lines.append(
        f"Dialogue: 1,{ass_time(cta_start)},{ass_time(total_duration)},Hook,,0,0,0,,{escape_ass(plan.cta)}"
    )
    return "\n".join(lines) + "\n"


def build_filter_complex(
    context: PipelineContext, *, has_audio: bool
) -> tuple[str, str]:
    plan = context.reel_edit_plan
    if not isinstance(plan, ReelEditPlan):
        raise ValueError("A validated AI ReelEditPlan is required for editing.")

    filters: list[str] = []
    for index, clip in enumerate(plan.clips):
        zoom_filter = "scale=iw*1.04:ih*1.04," if clip.zoom else ""
        filters.append(
            f"[0:v:0]trim=start={clip.start}:end={clip.end},"
            "setpts=PTS-STARTPTS,fps=30,"
            "scale=1080:1920:force_original_aspect_ratio=increase,"
            f"{zoom_filter}"
            f"crop=1080:1920:x='(iw-ow)*{clip.reframe_x}':"
            f"y='(ih-oh)*{clip.reframe_y}',setsar=1,format=yuv420p[v{index}]"
        )
        audio_input = "0:a:0" if has_audio else "1:a:0"
        filters.append(
            f"[{audio_input}]atrim=start={clip.start}:end={clip.end},"
            "asetpts=PTS-STARTPTS,aresample=48000,"
            "aformat=sample_fmts=fltp:channel_layouts=stereo,"
            f"{'loudnorm=I=-16:TP=-1.5:LRA=11' if has_audio else 'volume=0'}"
            f"[a{index}]"
        )

    concat_inputs = "".join(
        f"[v{index}][a{index}]" for index in range(len(plan.clips))
    )
    filters.append(
        f"{concat_inputs}concat=n={len(plan.clips)}:v=1:a=1[vcat][acat]"
    )
    subtitle_path = _escape_filter_path(context.subtitles_path)
    font_name = context.settings.ffmpeg_font_name.replace("'", "")
    filters.append(
        "[vcat]"
        f"subtitles=filename='{subtitle_path}':force_style='FontName={font_name}'"
        "[reel]"
    )
    return ";".join(filters), "[reel]"


class VideoEditingAgent:
    name = "video_editing"

    async def run(self, context: PipelineContext) -> dict[str, object]:
        plan = context.reel_edit_plan
        if not isinstance(plan, ReelEditPlan):
            raise ValueError("A validated AI ReelEditPlan is required for editing.")
        context.subtitles_path = context.work_dir / "persian-overlay.ass"
        context.subtitles_path.write_text(build_ass(context), encoding="utf-8")
        context.final_video_path = context.work_dir / "reel.mp4"
        duration = sum(clip.end - clip.start for clip in plan.clips)
        has_audio = bool(context.analysis.get("has_audio", False))
        filter_complex, output_video_label = build_filter_complex(
            context, has_audio=has_audio
        )
        command = [
            "ffmpeg",
            "-hide_banner",
            "-loglevel",
            "error",
            "-y",
            "-i",
            str(context.source_path),
        ]
        if not has_audio:
            command.extend(
                [
                    "-f",
                    "lavfi",
                    "-i",
                    "anullsrc=channel_layout=stereo:sample_rate=48000",
                ]
            )
        command.extend(
            [
                "-filter_complex",
                filter_complex,
                "-map",
                output_video_label,
                "-map",
                "[acat]",
                "-c:v",
                "libx264",
                "-preset",
                "veryfast",
                "-crf",
                "22",
                "-maxrate",
                "4M",
                "-bufsize",
                "8M",
                "-pix_fmt",
                "yuv420p",
                "-c:a",
                "aac",
                "-b:a",
                "128k",
                "-ar",
                "48000",
                "-movflags",
                "+faststart",
                str(context.final_video_path),
            ]
        )
        result = await asyncio.to_thread(
            subprocess.run,
            command,
            capture_output=True,
            text=True,
            timeout=900,
            check=False,
        )
        if result.returncode:
            raise RuntimeError(f"FFmpeg editing failed: {result.stderr[-1500:]}")
        if not context.final_video_path.is_file():
            raise RuntimeError("FFmpeg did not create the Reel video.")
        return {
            "file": str(context.final_video_path),
            "duration_seconds": duration,
            "clip_count": len(plan.clips),
            "clip_order": [clip.purpose for clip in plan.clips],
            "subtitle_segments": len(context.transcript_segments),
            "format": "mp4/h264/aac",
        }