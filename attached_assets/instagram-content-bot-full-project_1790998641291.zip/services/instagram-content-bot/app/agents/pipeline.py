import logging
from datetime import UTC, datetime

from sqlalchemy import select
from sqlalchemy.ext.asyncio import async_sessionmaker

from app.agents.approval import ApprovalAgent
from app.agents.caption import CaptionAgent
from app.agents.contracts import Agent, PipelineContext
from app.agents.cover import CoverAgent
from app.agents.quality_control import QualityControlAgent
from app.agents.storyboard import StoryboardAgent
from app.agents.video_analysis import VideoAnalysisAgent
from app.agents.video_editing import VideoEditingAgent
from app.core.storage import LocalMediaStorage
from app.models import AgentRun, LearningInsight, TelegramUser, VideoJob
from app.services.telegram_client import TelegramClient

logger = logging.getLogger(__name__)


async def run_content_pipeline(
    job: VideoJob,
    factory: async_sessionmaker,
    storage: LocalMediaStorage,
    telegram: TelegramClient,
    settings,
) -> None:
    job_id = job.id
    async with factory() as session:
        job = await session.get(VideoJob, job_id)
        if not job:
            raise ValueError(f"Video job {job_id} was not found.")
        user = await session.get(TelegramUser, job.chat_id)
        learned = await session.scalar(
            select(LearningInsight).where(
                LearningInsight.telegram_user_id == job.telegram_user_id,
                LearningInsight.insight_type == "hook_performance",
            )
        )
        learned_value = learned.value if learned else {}
        context = PipelineContext(
            job_id=job.id,
            chat_id=job.chat_id,
            telegram_user_id=job.telegram_user_id,
            media_token=job.media_token,
            source_key=job.original_file_key or "",
            work_dir=storage.resolve(f"{job.id}/work"),
            settings=settings,
            storage=storage,
            shop_name=user.shop_name if user else None,
            learned_hook=(learned_value or {}).get("recommended_hook"),
        )
        telegram_user_id = job.telegram_user_id
        chat_id = job.chat_id
        media_token = job.media_token
        source_key = job.original_file_key or ""
        stages: list[tuple[Agent, str]] = [
            (VideoAnalysisAgent(), "analyzing"),
            (StoryboardAgent(), "planning"),
            (CaptionAgent(), "writing_caption"),
            (VideoEditingAgent(), "editing"),
            (CoverAgent(), "creating_cover"),
            (QualityControlAgent(), "quality_check"),
            (ApprovalAgent(telegram), "sending_preview"),
        ]

        for agent, stage in stages:
            async with factory() as session:
                job = await session.get(VideoJob, job_id)
                if not job:
                    raise ValueError(f"Video job {job_id} was not found.")
                if job.status in {"awaiting_approval", "approved", "publishing", "published", "rejected"}:
                    return
                run = AgentRun(job_id=job_id, agent_name=agent.name, status="running")
                session.add(run)
                job.status = stage
                await session.commit()
            try:
                output = await agent.run(context)
                async with factory() as session:
                    job = await session.get(VideoJob, job_id)
                    run = await session.get(AgentRun, run.id)
                    if not job or not run:
                        raise ValueError(f"Video job {job_id} disappeared during processing.")
                    _persist_context(job, context)
                    run.status = "succeeded"
                    run.output_data = output
                    run.completed_at = datetime.now(UTC)
                    if agent.name == "approval":
                        job.status = "awaiting_approval"
                    await session.commit()
            except Exception as error:
                logger.exception("Agent %s failed for video job %s", agent.name, job_id)
                async with factory() as session:
                    job = await session.get(VideoJob, job_id)
                    run = await session.get(AgentRun, run.id)
                    if job:
                        job.status = "failed"
                        job.error_message = str(error)[:2000]
                    if run:
                        run.status = "failed"
                        run.error_message = str(error)[:2000]
                        run.completed_at = datetime.now(UTC)
                    await session.commit()
                if agent.name != "approval":
                    try:
                        await telegram.send_message(
                            chat_id,
                            "پردازش ویدیو کامل نشد. لطفاً ویدیو را دوباره ارسال کنید.",
                        )
                    except Exception:
                        logger.exception("Could not notify chat about failed video job %s", job_id)
                raise


def _persist_context(job: VideoJob, context: PipelineContext) -> None:
    if context.analysis:
        job.analysis = context.analysis
    if context.strategy:
        job.strategy = context.strategy
    if context.caption:
        job.caption = context.caption
        job.hook = context.hook
    if context.final_video_path and context.final_video_path.exists():
        context.final_video_key = f"{context.job_id}/reel.mp4"
        destination = context.storage.resolve(context.final_video_key)
        destination.parent.mkdir(parents=True, exist_ok=True)
        if destination != context.final_video_path:
            import shutil

            shutil.copy2(context.final_video_path, destination)
    if context.cover_path and context.cover_path.exists():
        context.cover_file_key = f"{context.job_id}/cover.jpg"
        destination = context.storage.resolve(context.cover_file_key)
        destination.parent.mkdir(parents=True, exist_ok=True)
        if destination != context.cover_path:
            import shutil

            shutil.copy2(context.cover_path, destination)
    if context.final_video_key:
        job.final_video_key = context.final_video_key
    if context.cover_file_key:
        job.cover_file_key = context.cover_file_key