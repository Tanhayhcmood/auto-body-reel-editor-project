from uuid import UUID

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

from app.agents.learning import LearningAgent
from app.core.config import Settings
from app.models import AnalyticsSnapshot, Post, VideoJob
from app.services.instagram_graph import InstagramGraphClient


class AnalyticsAgent:
    name = "analytics"

    def __init__(self, settings: Settings, factory: async_sessionmaker[AsyncSession]):
        self.settings = settings
        self.factory = factory

    async def run(self, post_id: UUID) -> dict[str, object]:
        async with self.factory() as session:
            post = await session.get(Post, post_id)
            if not post or not post.instagram_media_id:
                raise ValueError("The published Instagram media could not be found.")
            job = await session.get(VideoJob, post.job_id)
            if not job:
                raise ValueError("The source video job could not be found.")
            user_id = job.telegram_user_id
            metrics = await InstagramGraphClient(self.settings).fetch_insights(
                post.instagram_media_id
            )
            snapshot = AnalyticsSnapshot(
                post_id=post.id,
                reach=_integer_metric(metrics.get("reach")),
                plays=_integer_metric(metrics.get("plays") or metrics.get("views")),
                likes=_integer_metric(metrics.get("likes")),
                comments=_integer_metric(metrics.get("comments")),
                shares=_integer_metric(metrics.get("shares")),
                saves=_integer_metric(metrics.get("saved") or metrics.get("saves")),
                raw_metrics=metrics,
            )
            session.add(snapshot)
            post.analytics_status = "collected"
            await session.commit()
        learning = await LearningAgent(self.factory).run(user_id)
        return {"metrics": metrics, "learning": learning}


def _integer_metric(value: object) -> int | None:
    if value is None:
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        return None