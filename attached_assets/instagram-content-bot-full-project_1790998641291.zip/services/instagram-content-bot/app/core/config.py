from functools import lru_cache

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    database_url: str = ""
    redis_url: str = ""
    telegram_bot_token: str = ""
    telegram_webhook_secret: str = ""
    allowed_telegram_user_ids: str = ""
    public_media_base_url: str = ""
    meta_access_token: str = ""
    instagram_account_id: str = ""
    meta_graph_api_version: str = "v26.0"
    ai_api_key: str = ""
    ai_api_base_url: str = "https://api.openai.com/v1"
    ai_model: str = "gpt-4o-mini"
    ai_transcription_model: str = "whisper-1"
    debug_ai_artifacts: bool = False
    max_video_size_mb: int = Field(default=20, ge=1, le=2000)
    max_reel_duration_seconds: int = Field(default=90, ge=5, le=180)
    max_output_size_mb: int = Field(default=48, ge=5, le=2000)
    storage_dir: str = "/data"
    log_level: str = "INFO"
    ffmpeg_font_name: str = "Noto Naskh Arabic"
    telegram_api_base_url: str = "https://api.telegram.org"
    meta_processing_poll_seconds: float = Field(default=4.0, gt=0, le=30)
    meta_processing_max_attempts: int = Field(default=45, ge=1, le=180)

    @property
    def allowed_user_ids(self) -> set[int]:
        return {
            int(value.strip())
            for value in self.allowed_telegram_user_ids.split(",")
            if value.strip()
        }

    def validate_runtime(self) -> None:
        try:
            allowlisted_users = self.allowed_user_ids
        except ValueError:
            raise RuntimeError(
                "ALLOWED_TELEGRAM_USER_IDS must be a comma-separated list of numeric Telegram user IDs."
            ) from None

        missing = [
            name
            for name, value in (
                ("DATABASE_URL", self.database_url),
                ("REDIS_URL", self.redis_url),
                ("TELEGRAM_BOT_TOKEN", self.telegram_bot_token),
                ("TELEGRAM_WEBHOOK_SECRET", self.telegram_webhook_secret),
            )
            if not value.strip()
        ]
        if not allowlisted_users:
            missing.append("ALLOWED_TELEGRAM_USER_IDS")
        if missing:
            raise RuntimeError(f"Missing required configuration: {', '.join(missing)}")


@lru_cache
def get_settings() -> Settings:
    return Settings()