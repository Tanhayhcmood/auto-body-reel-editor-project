from pathlib import Path


class LocalMediaStorage:
    """Single-host MVP storage; mount the same durable volume into API and workers."""

    def __init__(self, root: str | Path):
        self.root = Path(root).resolve()
        self.root.mkdir(parents=True, exist_ok=True)

    def resolve(self, key: str) -> Path:
        path = (self.root / key).resolve()
        if not path.is_relative_to(self.root):
            raise ValueError("Invalid media storage key")
        return path

    def save(self, key: str, content: bytes) -> Path:
        path = self.resolve(key)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(content)
        return path

    def public_url(self, base_url: str, job_id: str, token: str, name: str) -> str:
        if not base_url:
            raise RuntimeError(
                "PUBLIC_MEDIA_BASE_URL is required so Meta can fetch the media."
            )
        return (
            f"{base_url.rstrip('/')}/media/{job_id}/{token}/{name}"
        )