import hmac
import logging

from arq.connections import ArqRedis
from fastapi import APIRouter, Header, HTTPException, Request

from app.core.config import Settings
from app.schemas.telegram import TelegramUpdateSchema

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/webhooks", tags=["telegram"])


@router.post("/telegram")
async def telegram_webhook(
    update: TelegramUpdateSchema,
    request: Request,
    secret_token: str | None = Header(default=None, alias="X-Telegram-Bot-Api-Secret-Token"),
) -> dict[str, bool]:
    settings: Settings = request.app.state.settings
    if not settings.telegram_webhook_secret:
        raise HTTPException(status_code=503, detail="Telegram webhook secret is not configured.")
    if not secret_token or not hmac.compare_digest(
        secret_token, settings.telegram_webhook_secret
    ):
        raise HTTPException(status_code=401, detail="Invalid webhook secret.")

    sender_id = None
    if update.message and update.message.from_user:
        sender_id = update.message.from_user.id
    elif update.callback_query:
        sender_id = update.callback_query.from_user.id
    if (
        sender_id is not None
        and settings.allowed_user_ids
        and sender_id not in settings.allowed_user_ids
    ):
        logger.warning("Rejected webhook update from a Telegram user outside the allowlist")
        return {"ok": True}

    pool: ArqRedis = request.app.state.arq_pool
    await pool.enqueue_job(
        "process_telegram_update",
        update.model_dump(mode="json", by_alias=True, exclude_none=True),
        _job_id=f"telegram-update-{update.update_id}",
    )
    return {"ok": True}