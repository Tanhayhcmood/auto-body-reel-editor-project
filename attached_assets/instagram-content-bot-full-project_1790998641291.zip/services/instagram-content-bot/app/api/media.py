import hmac
from pathlib import Path
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import FileResponse
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_session
from app.core.storage import LocalMediaStorage
from app.models import VideoJob

router = APIRouter(tags=["media"])


@router.get("/media/{job_id}/{token}/{asset}")
async def public_media(
    request: Request,
    job_id: UUID,
    token: str,
    asset: str,
    session: AsyncSession = Depends(get_session),
) -> FileResponse:
    if asset not in {"video", "cover"}:
        raise HTTPException(status_code=404, detail="Media not found.")
    job = await session.get(VideoJob, job_id)
    if not job or not hmac.compare_digest(token, job.media_token):
        raise HTTPException(status_code=404, detail="Media not found.")
    key = job.final_video_key if asset == "video" else job.cover_file_key
    if not key:
        raise HTTPException(status_code=404, detail="Media not found.")
    storage = LocalMediaStorage(request.app.state.settings.storage_dir)
    path: Path = storage.resolve(key)
    if not path.is_file():
        raise HTTPException(status_code=404, detail="Media not found.")
    media_type = "video/mp4" if asset == "video" else "image/jpeg"
    return FileResponse(
        path,
        media_type=media_type,
        filename=path.name,
        headers={"Cache-Control": "public, max-age=3600"},
    )