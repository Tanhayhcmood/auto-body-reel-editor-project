from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel
from sqlalchemy import text

router = APIRouter(tags=["health"])


class HealthResponse(BaseModel):
    status: str


@router.get("/health/live", response_model=HealthResponse)
async def liveness() -> HealthResponse:
    return HealthResponse(status="ok")


@router.get("/health/ready", response_model=HealthResponse)
async def readiness(request: Request) -> HealthResponse:
    try:
        async with request.app.state.session_factory() as session:
            await session.execute(text("select 1"))
        await request.app.state.redis.ping()
    except Exception as error:
        raise HTTPException(status_code=503, detail="A required dependency is unavailable.") from error
    return HealthResponse(status="ready")