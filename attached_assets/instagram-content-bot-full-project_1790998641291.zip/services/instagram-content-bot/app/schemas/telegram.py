from pydantic import BaseModel, ConfigDict, Field


class TelegramChat(BaseModel):
    id: int


class TelegramUserSchema(BaseModel):
    id: int
    username: str | None = None
    language_code: str | None = None


class TelegramVideo(BaseModel):
    file_id: str
    file_size: int | None = None
    file_name: str | None = None
    mime_type: str | None = None


class TelegramMessage(BaseModel):
    message_id: int
    chat: TelegramChat
    from_user: TelegramUserSchema | None = Field(default=None, alias="from")
    text: str | None = None
    video: TelegramVideo | None = None
    document: TelegramVideo | None = None

    model_config = ConfigDict(populate_by_name=True, extra="ignore")


class TelegramCallbackQuery(BaseModel):
    id: str
    from_user: TelegramUserSchema = Field(alias="from")
    data: str | None = None
    message: TelegramMessage | None = None

    model_config = ConfigDict(populate_by_name=True, extra="ignore")


class TelegramUpdateSchema(BaseModel):
    update_id: int
    message: TelegramMessage | None = None
    callback_query: TelegramCallbackQuery | None = None

    model_config = ConfigDict(extra="ignore")


class HealthResponse(BaseModel):
    status: str