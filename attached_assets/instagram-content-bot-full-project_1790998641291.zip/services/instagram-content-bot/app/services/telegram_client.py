from pathlib import Path
from typing import Any

import httpx

from app.core.config import Settings


class TelegramClient:
    def __init__(self, settings: Settings):
        if not settings.telegram_bot_token:
            raise RuntimeError("TELEGRAM_BOT_TOKEN is not configured.")
        self.settings = settings
        self.api_base = (
            f"{settings.telegram_api_base_url.rstrip('/')}/bot"
            f"{settings.telegram_bot_token}"
        )
        self.file_base = (
            f"{settings.telegram_api_base_url.rstrip('/')}/file/bot"
            f"{settings.telegram_bot_token}"
        )

    async def _post(self, method: str, data: dict[str, Any]) -> dict[str, Any]:
        try:
            async with httpx.AsyncClient(timeout=60) as client:
                response = await client.post(f"{self.api_base}/{method}", json=data)
        except httpx.RequestError:
            raise RuntimeError(f"Telegram {method} network request failed.") from None
        if response.is_error:
            raise RuntimeError(f"Telegram {method} failed (HTTP {response.status_code}).")
        result = response.json()
        if not result.get("ok"):
            raise RuntimeError(f"Telegram {method} returned an unsuccessful response.")
        return result["result"]

    async def send_message(
        self, chat_id: int, text: str, reply_markup: dict[str, Any] | None = None
    ) -> None:
        payload: dict[str, Any] = {"chat_id": chat_id, "text": text}
        if reply_markup:
            payload["reply_markup"] = reply_markup
        await self._post("sendMessage", payload)

    async def send_photo(self, chat_id: int, path: Path, caption: str) -> None:
        try:
            async with httpx.AsyncClient(timeout=120) as client, path.open("rb") as image:
                response = await client.post(
                    f"{self.api_base}/sendPhoto",
                    data={"chat_id": str(chat_id), "caption": caption[:1024]},
                    files={"photo": (path.name, image, "image/jpeg")},
                )
        except httpx.RequestError:
            raise RuntimeError("Telegram cover upload request failed.") from None
        if response.is_error or not response.json().get("ok"):
            raise RuntimeError("Telegram could not send the cover image.")

    async def send_video(
        self,
        chat_id: int,
        path: Path,
        caption: str,
        reply_markup: dict[str, Any] | None = None,
    ) -> None:
        data: dict[str, Any] = {
            "chat_id": str(chat_id),
            "caption": caption[:900],
            "supports_streaming": "true",
        }
        if reply_markup:
            import json

            data["reply_markup"] = json.dumps(reply_markup, ensure_ascii=False)
        try:
            async with httpx.AsyncClient(timeout=300) as client, path.open("rb") as video:
                response = await client.post(
                    f"{self.api_base}/sendVideo",
                    data=data,
                    files={"video": (path.name, video, "video/mp4")},
                )
        except httpx.RequestError:
            raise RuntimeError("Telegram video upload request failed.") from None
        if response.is_error or not response.json().get("ok"):
            raise RuntimeError("Telegram could not send the Reel preview.")

    async def answer_callback_query(self, callback_query_id: str, text: str) -> None:
        await self._post(
            "answerCallbackQuery",
            {"callback_query_id": callback_query_id, "text": text[:180]},
        )

    async def download_file(
        self, file_id: str, destination: Path, max_bytes: int | None = None
    ) -> str:
        try:
            async with httpx.AsyncClient(timeout=60) as client:
                response = await client.post(
                    f"{self.api_base}/getFile", json={"file_id": file_id}
                )
                if response.is_error or not response.json().get("ok"):
                    raise RuntimeError("Telegram could not retrieve the uploaded video.")
                file_path = response.json()["result"]["file_path"]
                destination.parent.mkdir(parents=True, exist_ok=True)
                destination.unlink(missing_ok=True)
                async with client.stream("GET", f"{self.file_base}/{file_path}") as download:
                    if download.is_error:
                        raise RuntimeError("Telegram video download failed.")
                    content_length = download.headers.get("content-length")
                    if max_bytes and content_length and int(content_length) > max_bytes:
                        raise ValueError("Uploaded video exceeds the configured size limit.")
                    with destination.open("wb") as output:
                        bytes_written = 0
                        async for chunk in download.aiter_bytes():
                            bytes_written += len(chunk)
                            if max_bytes and bytes_written > max_bytes:
                                raise ValueError(
                                    "Uploaded video exceeds the configured size limit."
                                )
                            output.write(chunk)
        except httpx.RequestError:
            destination.unlink(missing_ok=True)
            raise RuntimeError("Telegram video download request failed.") from None
        except Exception:
            destination.unlink(missing_ok=True)
            raise
        return file_path