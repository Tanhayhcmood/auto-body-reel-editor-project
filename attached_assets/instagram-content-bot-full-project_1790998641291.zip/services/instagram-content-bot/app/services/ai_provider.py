import base64
import json
import re
from pathlib import Path
from typing import Any

import httpx

from app.core.config import Settings
from app.services.video_segmentation import (
    MAX_REPRESENTATIVE_IMAGES,
    SegmentAnalysis,
    VideoSegment,
    validate_segment_analyses,
)


REEL_EDIT_SYSTEM_PROMPT = """تو یک کارگردان خلاق و تدوینگر حرفه‌ای محتوای اینستاگرام برای صافکاری خودرو هستی.
همه‌ی بخش‌های تحلیل‌شده‌ی ویدیو را با هم مقایسه کن و فقط بر اساس شواهد دیداری همان بخش‌ها و متن پیاده‌سازی‌شده تصمیم بگیر. هرگز آسیب، رویداد، فرایند تعمیر، نتیجه، ابزار یا کیفیتی را که در شواهد قابل مشاهده نیست اختراع نکن. اگر قبلِ تعمیر، فرایند یا نتیجه‌ی نهایی دیده نمی‌شود، آن مرحله را نساز؛ داستان را با محدودیت ویدیوی واقعی تطبیق بده.

پیش از انتخاب، درونی بررسی کن: قوی‌ترین لحظه‌ی تصویری و شروع کدام است؛ کدام بخش آسیب، تعمیر و نتیجه را واقعاً نشان می‌دهد؛ و کدام بخش‌ها تکراری، تار یا کم‌ارزش‌اند و باید حذف شوند. زنجیره‌ی فکری را در خروجی ننویس؛ فقط دلیل کوتاه و مبتنی بر شواهد برای هر کلیپ انتخاب‌شده ارائه کن.

پنج مفهوم هوک فارسی بساز که هرکدام متن، بازه‌ی دقیق منبع و دلیل مبتنی بر شواهد داشته باشد. یکی را به عنوان selected_hook انتخاب کن. بازه‌ی selected_hook باید دقیقاً با نخستین کلیپ purpose=hook یکی باشد. در صورت پشتیبانی تصویر، روایت HOOK → BEFORE → REPAIR PROCESS → SATISFYING DETAIL → FINAL RESULT → CTA را ترجیح بده؛ این ترتیب اجباری نیست. تعداد کلیپ را بر اساس شواهد انتخاب کن، نه یک عدد ثابت. ترتیب clips ترتیب نهایی تدوین است؛ آن را بر اساس زمان منبع مرتب نکن.

تمام زمان‌ها ثانیه و نسبت به ویدیوی منبع هستند؛ هیچ زمان خارج از منبع یا کلیپی که با شواهد قابل ردیابی نیست انتخاب نکن. خروجی فقط JSON معتبر با این ساختار باشد:
{"concept":"...","hook_concepts":[{"text":"...","start":0.0,"end":2.0,"reason":"..."},{"text":"...","start":2.0,"end":4.0,"reason":"..."},{"text":"...","start":4.0,"end":6.0,"reason":"..."},{"text":"...","start":6.0,"end":8.0,"reason":"..."},{"text":"...","start":8.0,"end":10.0,"reason":"..."}],"selected_hook":{"text":"...","start":0.0,"end":2.0,"reason":"..."}, "clips":[{"start":0.0,"end":2.0,"purpose":"hook","reason":"...","zoom":false,"reframe_x":0.5,"reframe_y":0.5}], "target_duration":2.0,"overlay_text":[{"start":0.0,"end":2.0,"text":"..."}],"cta":"..."}
purpose باید کوتاه و متناسب با شواهد باشد؛ برای هوک از hook استفاده کن. دلیل هر کلیپ باید مشخص کند چرا همان بخش ارزش انتخاب دارد. zoom فقط در صورت فایده‌ی واقعی فعال باشد. reframe_x و reframe_y مرکز برش ۹:۱۶ را بین ۰ و ۱ تعیین می‌کنند. زمان hook باید با کلیپ اول یکسان باشد. target_duration برابر مجموع مدت کلیپ‌ها باشد و از سقف تنظیم‌شده بیشتر نشود. هیچ توضیح یا زنجیره‌ی فکری بیرون از JSON نده."""

SEGMENT_ANALYSIS_SYSTEM_PROMPT = """تو یک تحلیل‌گر ویدیوی خودرو هستی. تصاویر ورودی به چند بخش زمان‌دار تقسیم شده‌اند؛ فریم‌های هر بخش با ترتیب زمانی آمده‌اند. هر بخش را به عنوان یک توالی تصویری تحلیل کن، نه مجموعه‌ای از تصاویر مستقل. تغییرات و رویدادهای قابل مشاهده میان فریم‌های همان بخش را خلاصه کن و همه‌ی بخش‌ها را برای تشخیص تکرار با هم مقایسه کن.
فقط چیزهایی را گزارش کن که در فریم‌های ارائه‌شده واقعاً قابل مشاهده‌اند. آسیب، ابزار، رنگ‌آمیزی، سنباده‌کاری، پولیش، تعمیر فرورفتگی یا نتیجه را حدس نزن. رویدادها را به ترتیب مشاهده بنویس؛ اگر شواهد کافی نیست، summary را با «نامشخص از فریم‌های موجود» توضیح بده، visual_events و labels را خالی بگذار و امتیازهای مبتنی بر اطمینان را پایین نگه دار.
برچسب‌های مجاز: damaged_area, before_repair, repair_process, tools_action, close_up_detail, satisfying_moment, final_result, vehicle_reveal, painting, sanding, polishing, dent_repair, uninteresting, repetitive, blurry.
برای هر segment ورودی دقیقاً یک تحلیل با همان segment_id، start و end برگردان. scoreها باید بین ۰ و ۱ باشند؛ کیفیت تصویر، جذابیت بصری، ارتباط با صافکاری و ارزش تغییر را جداگانه بسنج. خروجی فقط JSON با کلید segments باشد."""


class OpenAICompatibleProvider:
    """Optional provider adapter; no network calls occur without an API key."""

    def __init__(self, settings: Settings):
        self.settings = settings
        self.enabled = bool(settings.ai_api_key.strip())

    def _headers(self) -> dict[str, str]:
        return {
            "Authorization": f"Bearer {self.settings.ai_api_key}",
            "Content-Type": "application/json",
        }

    async def _chat(self, messages: list[dict[str, Any]]) -> str:
        if not self.enabled:
            raise RuntimeError("AI_API_KEY is not configured.")
        async with httpx.AsyncClient(timeout=180) as client:
            response = await client.post(
                f"{self.settings.ai_api_base_url.rstrip('/')}/chat/completions",
                headers=self._headers(),
                json={
                    "model": self.settings.ai_model,
                    "messages": messages,
                    "temperature": 0.5,
                    "response_format": {"type": "json_object"},
                },
            )
        if response.is_error:
            raise RuntimeError(
                f"AI provider request failed (HTTP {response.status_code})."
            )
        try:
            return str(response.json()["choices"][0]["message"]["content"])
        except (KeyError, IndexError, TypeError) as error:
            raise RuntimeError("AI provider returned an unexpected response.") from error

    @staticmethod
    def _json_object(content: str) -> dict[str, Any]:
        normalized = re.sub(r"^```(?:json)?\s*|\s*```$", "", content.strip())
        try:
            result = json.loads(normalized)
        except json.JSONDecodeError as error:
            raise RuntimeError("AI provider did not return valid JSON.") from error
        if not isinstance(result, dict):
            raise RuntimeError("AI provider JSON response must be an object.")
        return result

    async def analyze_segments(
        self, segments: list[VideoSegment]
    ) -> list[dict[str, Any]]:
        if not segments:
            raise RuntimeError("No video segments were created for AI analysis.")
        image_count = sum(len(segment.representative_frames) for segment in segments)
        if image_count > MAX_REPRESENTATIVE_IMAGES:
            raise RuntimeError(
                "Segment analysis exceeds the configured representative-image limit."
            )
        content: list[dict[str, Any]] = [
            {
                "type": "text",
                "text": (
                    "همه‌ی بخش‌ها را با هم مقایسه کن. هر بخش یک توالی زمانی از چند فریم "
                    "نماینده دارد؛ متن هر تصویر timestamp دقیق آن است. مرزهای بخش را حفظ "
                    "کن و برای هر بخش ورودی دقیقاً یک تحلیل برگردان."
                ),
            }
        ]
        for segment in segments:
            content.append(
                {
                    "type": "text",
                    "text": (
                        f"شروع بخش {segment.segment_id}: "
                        f"{segment.start:.4f} تا {segment.end:.4f} ثانیه؛ "
                        f"مدت {segment.duration:.4f} ثانیه."
                    ),
                }
            )
            for frame in segment.representative_frames:
                encoded = base64.b64encode(frame.path.read_bytes()).decode("ascii")
                content.append(
                    {
                        "type": "text",
                        "text": (
                            f"فریم نماینده‌ی بخش {segment.segment_id} "
                            f"در {frame.timestamp:.4f} ثانیه"
                        ),
                    }
                )
                content.append(
                    {
                        "type": "image_url",
                        "image_url": {"url": f"data:image/jpeg;base64,{encoded}"},
                    }
                )
            content.append(
                {"type": "text", "text": f"پایان بخش {segment.segment_id}."}
            )
        result = self._json_object(
            await self._chat(
                [
                    {"role": "system", "content": SEGMENT_ANALYSIS_SYSTEM_PROMPT},
                    {"role": "user", "content": content},
                ]
            )
        )
        raw_segments = result.get("segments")
        if not isinstance(raw_segments, list):
            raise RuntimeError("AI segment analysis must return a segments array.")
        try:
            analyses: list[SegmentAnalysis] = validate_segment_analyses(
                raw_segments, segments
            )
        except Exception as error:
            raise RuntimeError(f"AI returned invalid segment analysis: {error}") from error
        return [analysis.model_dump(mode="json") for analysis in analyses]

    async def generate_reel_edit_plan(
        self,
        *,
        duration_seconds: float,
        max_duration_seconds: float,
        analysis: dict[str, Any],
        transcript: str,
    ) -> dict[str, Any]:
        return await self._request_reel_edit_plan(
            {
                "source_duration_seconds": duration_seconds,
                "maximum_reel_duration_seconds": max_duration_seconds,
                "scene_change_timestamps": analysis.get("scene_change_seconds", []),
                "analyzed_segments": analysis.get("segments", []),
                "transcript": transcript,
                "instructions": (
                    "Compare every analyzed segment before choosing clips. Use the segment "
                    "scores, labels, events and summaries as evidence. Build a truthful edit; "
                    "do not invent missing before/repair/result stages. Keep timestamps within "
                    "the source, make selected_hook match the first hook clip, and keep the "
                    "sum of clip durations within maximum_reel_duration_seconds."
                ),
            }
        )

    async def repair_reel_edit_plan(
        self,
        *,
        duration_seconds: float,
        max_duration_seconds: float,
        analysis: dict[str, Any],
        transcript: str,
        invalid_plan: dict[str, Any],
        validation_errors: str,
    ) -> dict[str, Any]:
        return await self._request_reel_edit_plan(
            {
                "source_duration_seconds": duration_seconds,
                "maximum_reel_duration_seconds": max_duration_seconds,
                "scene_change_timestamps": analysis.get("scene_change_seconds", []),
                "analyzed_segments": analysis.get("segments", []),
                "transcript": transcript,
                "invalid_plan": invalid_plan,
                "validation_errors": validation_errors,
                "instructions": (
                    "Repair the invalid plan using only the same source evidence. Correct "
                    "the validation errors, preserve valid creative decisions, and return "
                    "only the required JSON object. This is the final attempt."
                ),
            }
        )

    async def _request_reel_edit_plan(
        self, payload: dict[str, Any]
    ) -> dict[str, Any]:
        return self._json_object(
            await self._chat(
                [
                    {"role": "system", "content": REEL_EDIT_SYSTEM_PROMPT},
                    {
                        "role": "user",
                        "content": json.dumps(payload, ensure_ascii=False),
                    },
                ]
            )
        )

    async def transcribe(self, path: Path) -> list[dict[str, Any]]:
        if not self.enabled:
            return []
        headers = {"Authorization": f"Bearer {self.settings.ai_api_key}"}
        with path.open("rb") as video:
            async with httpx.AsyncClient(timeout=300) as client:
                response = await client.post(
                    f"{self.settings.ai_api_base_url.rstrip('/')}/audio/transcriptions",
                    headers=headers,
                    data={
                        "model": self.settings.ai_transcription_model,
                        "language": "fa",
                        "response_format": "verbose_json",
                    },
                    files={"file": (path.name, video, "application/octet-stream")},
                )
        if response.is_error:
            raise RuntimeError(
                f"Speech transcription failed (HTTP {response.status_code})."
            )
        data = response.json()
        segments = data.get("segments", [])
        return [
            {
                "start": float(segment["start"]),
                "end": float(segment["end"]),
                "text": str(segment.get("text", "")).strip(),
            }
            for segment in segments
            if segment.get("text") and float(segment["end"]) > float(segment["start"])
        ]

    async def generate_caption(
        self,
        *,
        analysis: dict[str, Any],
        strategy: dict[str, Any],
        transcript: str,
        learned_hook: str | None,
        shop_name: str | None,
    ) -> dict[str, Any]:
        prompt = {
            "language": "Persian (Iran)",
            "shop_name": shop_name,
            "video_summary": analysis.get("visual_notes", {}),
            "clip": strategy,
            "transcript": transcript[:3000],
            "proven_hook_style": learned_hook,
            "requirements": [
                "Return a short, compelling Persian hook for the first seconds of a Reel.",
                "Write a truthful caption for auto-body repair customers; do not invent repairs or guarantees.",
                "Include a clear Persian call to action.",
                "Return only a JSON object with string fields hook, caption, cta.",
            ],
        }
        result = self._json_object(
            await self._chat(
                [
                    {
                        "role": "system",
                        "content": "You write accurate, professional Persian Instagram content for an auto body repair shop.",
                    },
                    {"role": "user", "content": json.dumps(prompt, ensure_ascii=False)},
                ]
            )
        )
        for field in ("hook", "caption", "cta"):
            if not isinstance(result.get(field), str) or not result[field].strip():
                raise RuntimeError(f"AI caption response is missing {field}.")
        return result