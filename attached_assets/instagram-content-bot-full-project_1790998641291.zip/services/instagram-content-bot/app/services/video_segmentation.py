import asyncio
import json
import math
import re
import subprocess
from pathlib import Path
from typing import Annotated, Literal, Self

from pydantic import BaseModel, ConfigDict, Field, StringConstraints, model_validator


MAX_SEGMENTS = 16
MAX_REPRESENTATIVE_IMAGES = 48
MAX_BASE_SEGMENT_SECONDS = 8.0
MIN_BOUNDARY_GAP_SECONDS = 1.25

SegmentLabel = Literal[
    "damaged_area",
    "before_repair",
    "repair_process",
    "tools_action",
    "close_up_detail",
    "satisfying_moment",
    "final_result",
    "vehicle_reveal",
    "painting",
    "sanding",
    "polishing",
    "dent_repair",
    "uninteresting",
    "repetitive",
    "blurry",
]
ObservationText = Annotated[str, StringConstraints(strip_whitespace=True, min_length=1)]


class RepresentativeFrame(BaseModel):
    model_config = ConfigDict(extra="forbid")

    timestamp: float = Field(ge=0, allow_inf_nan=False)
    path: Path


class VideoSegment(BaseModel):
    model_config = ConfigDict(extra="forbid")

    segment_id: str = Field(min_length=1)
    start: float = Field(ge=0, allow_inf_nan=False)
    end: float = Field(gt=0, allow_inf_nan=False)
    duration: float = Field(gt=0, allow_inf_nan=False)
    representative_frames: list[RepresentativeFrame] = Field(min_length=2, max_length=4)

    @model_validator(mode="after")
    def validate_segment_timing(self) -> Self:
        if self.end <= self.start:
            raise ValueError("Segment end must be greater than segment start.")
        if abs((self.end - self.start) - self.duration) > 0.01:
            raise ValueError("Segment duration must match its start and end timestamps.")
        if any(
            not self.start <= frame.timestamp < self.end
            for frame in self.representative_frames
        ):
            raise ValueError("Representative frame timestamps must be inside the segment.")
        return self


class SegmentAnalysis(BaseModel):
    model_config = ConfigDict(extra="forbid")

    segment_id: str = Field(min_length=1)
    start: float = Field(ge=0, allow_inf_nan=False)
    end: float = Field(gt=0, allow_inf_nan=False)
    summary: ObservationText
    visual_events: list[ObservationText] = Field(max_length=24)
    labels: list[SegmentLabel] = Field(max_length=15)
    quality_score: float = Field(ge=0, le=1, allow_inf_nan=False)
    interest_score: float = Field(ge=0, le=1, allow_inf_nan=False)
    repair_relevance: float = Field(ge=0, le=1, allow_inf_nan=False)
    transformation_value: float = Field(ge=0, le=1, allow_inf_nan=False)

    @model_validator(mode="after")
    def validate_segment_range(self) -> Self:
        if self.end <= self.start:
            raise ValueError("Analyzed segment end must be greater than its start.")
        return self


async def detect_scene_changes(video_path: Path) -> list[float]:
    def detect() -> list[float]:
        result = subprocess.run(
            [
                "ffmpeg",
                "-hide_banner",
                "-i",
                str(video_path),
                "-vf",
                "select='gt(scene,0.28)',showinfo",
                "-an",
                "-f",
                "null",
                "-",
            ],
            capture_output=True,
            text=True,
            timeout=240,
            check=False,
        )
        if result.returncode:
            raise RuntimeError(f"FFmpeg scene detection failed: {result.stderr[-1000:]}")
        return [
            float(value)
            for value in re.findall(r"pts_time:([0-9]+(?:\.[0-9]+)?)", result.stderr)
        ]

    return await asyncio.to_thread(detect)


def build_segment_ranges(
    duration: float,
    scene_changes: list[float],
    *,
    max_segments: int = MAX_SEGMENTS,
) -> list[tuple[float, float]]:
    """Combine scene boundaries with evenly distributed time boundaries."""
    if not math.isfinite(duration) or duration <= 0:
        raise ValueError("Video duration must be a positive finite number.")
    if max_segments < 1:
        raise ValueError("At least one video segment must be allowed.")

    base_boundary_count = min(
        max_segments // 2,
        max(0, math.ceil(duration / MAX_BASE_SEGMENT_SECONDS) - 1),
    )
    time_boundaries = [
        duration * index / (base_boundary_count + 1)
        for index in range(1, base_boundary_count + 1)
    ]
    available_scene_boundaries = max_segments - 1 - len(time_boundaries)
    minimum_gap = min(MIN_BOUNDARY_GAP_SECONDS, duration / 4)
    chosen_scene_boundaries: list[float] = []

    for raw_timestamp in sorted(scene_changes):
        try:
            timestamp = float(raw_timestamp)
        except (TypeError, ValueError):
            continue
        if not math.isfinite(timestamp) or not 0 < timestamp < duration:
            continue
        if any(
            abs(timestamp - boundary) < minimum_gap
            for boundary in [*time_boundaries, *chosen_scene_boundaries]
        ):
            continue
        chosen_scene_boundaries.append(timestamp)

    if len(chosen_scene_boundaries) > available_scene_boundaries:
        if available_scene_boundaries <= 0:
            chosen_scene_boundaries = []
        else:
            chosen_scene_boundaries = _evenly_spaced(
                chosen_scene_boundaries, available_scene_boundaries
            )

    boundaries = sorted({0.0, duration, *time_boundaries, *chosen_scene_boundaries})
    return [
        (round(start, 4), round(end, 4))
        for start, end in zip(boundaries, boundaries[1:], strict=False)
        if end > start
    ]


def _evenly_spaced(values: list[float], limit: int) -> list[float]:
    if limit <= 0:
        return []
    if len(values) <= limit:
        return values
    if limit == 1:
        return [values[len(values) // 2]]
    indices = {
        round(index * (len(values) - 1) / (limit - 1)) for index in range(limit)
    }
    return [values[index] for index in sorted(indices)]


def _frame_counts(ranges: list[tuple[float, float]]) -> list[int]:
    desired_counts = [
        2 if end - start <= 5 else 3 if end - start <= 12 else 4
        for start, end in ranges
    ]
    counts = [2] * len(ranges)
    remaining = max(0, MAX_REPRESENTATIVE_IMAGES - sum(counts))
    longest_first = sorted(
        range(len(ranges)),
        key=lambda index: ranges[index][1] - ranges[index][0],
        reverse=True,
    )
    for target in (3, 4):
        for index in longest_first:
            if remaining <= 0:
                break
            if desired_counts[index] >= target and counts[index] < target:
                counts[index] = target
                remaining -= 1
    return counts


def _representative_timestamps(
    start: float, end: float, frame_count: int
) -> list[float]:
    duration = end - start
    return [
        round(start + duration * index / (frame_count + 1), 4)
        for index in range(1, frame_count + 1)
    ]


async def create_video_segments(
    video_path: Path,
    duration: float,
    work_dir: Path,
) -> tuple[list[float], list[VideoSegment]]:
    """Detect cuts, combine them with time sampling, and extract bounded frame sets."""
    scene_changes = await detect_scene_changes(video_path)
    ranges = build_segment_ranges(duration, scene_changes)
    frame_counts = _frame_counts(ranges)
    work_dir.mkdir(parents=True, exist_ok=True)
    semaphore = asyncio.Semaphore(4)

    async def extract_frame(
        segment_index: int, frame_index: int, timestamp: float
    ) -> RepresentativeFrame:
        frame_path = work_dir / (
            f"segment-{segment_index + 1:02d}-frame-{frame_index + 1:02d}.jpg"
        )

        def write_frame() -> None:
            result = subprocess.run(
                [
                    "ffmpeg",
                    "-hide_banner",
                    "-loglevel",
                    "error",
                    "-y",
                    "-ss",
                    str(timestamp),
                    "-i",
                    str(video_path),
                    "-frames:v",
                    "1",
                    "-vf",
                    "scale=480:-2",
                    "-q:v",
                    "5",
                    str(frame_path),
                ],
                capture_output=True,
                text=True,
                timeout=60,
                check=False,
            )
            if result.returncode or not frame_path.is_file():
                raise RuntimeError(
                    "Could not extract representative video frame: "
                    f"{result.stderr[-1000:]}"
                )

        async with semaphore:
            await asyncio.to_thread(write_frame)
        return RepresentativeFrame(timestamp=timestamp, path=frame_path)

    async def create_segment(
        index: int, time_range: tuple[float, float], frame_count: int
    ) -> VideoSegment:
        start, end = time_range
        timestamps = _representative_timestamps(start, end, frame_count)
        frames = await asyncio.gather(
            *(
                extract_frame(index, frame_index, timestamp)
                for frame_index, timestamp in enumerate(timestamps)
            )
        )
        return VideoSegment(
            segment_id=f"segment_{index + 1:03d}",
            start=start,
            end=end,
            duration=round(end - start, 4),
            representative_frames=frames,
        )

    segments = await asyncio.gather(
        *(
            create_segment(index, time_range, frame_counts[index])
            for index, time_range in enumerate(ranges)
        )
    )
    return scene_changes, list(segments)


def validate_segment_analyses(
    raw_segments: list[object], source_segments: list[VideoSegment]
) -> list[SegmentAnalysis]:
    if len(raw_segments) != len(source_segments):
        raise ValueError("AI must return exactly one analysis for every video segment.")

    analyses: list[SegmentAnalysis] = []
    for raw_segment, source_segment in zip(raw_segments, source_segments, strict=True):
        analysis = SegmentAnalysis.model_validate(raw_segment)
        if analysis.segment_id != source_segment.segment_id:
            raise ValueError("AI changed the segment order or segment ID.")
        if (
            abs(analysis.start - source_segment.start) > 0.01
            or abs(analysis.end - source_segment.end) > 0.01
        ):
            raise ValueError("AI changed a source segment's timestamps.")
        analyses.append(
            analysis.model_copy(
                update={"start": source_segment.start, "end": source_segment.end}
            )
        )
    return analyses


def write_debug_json(
    work_dir: Path, filename: str, payload: object, *, enabled: bool
) -> Path | None:
    if not enabled:
        return None
    if filename not in {"analysis.json", "segments.json", "edit-plan.json"}:
        raise ValueError("Unsupported AI debug artifact filename.")
    work_dir.mkdir(parents=True, exist_ok=True)
    path = work_dir / filename
    path.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2, allow_nan=False) + "\n",
        encoding="utf-8",
    )
    return path