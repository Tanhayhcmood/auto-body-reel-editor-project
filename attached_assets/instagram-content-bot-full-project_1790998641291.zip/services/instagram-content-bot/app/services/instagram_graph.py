import asyncio
from typing import Any

import httpx

from app.core.config import Settings


class InstagramGraphClient:
    """Small client for the official Meta Graph API publishing/insights endpoints."""

    def __init__(self, settings: Settings):
        if not settings.meta_access_token or not settings.instagram_account_id:
            raise RuntimeError(
                "META_ACCESS_TOKEN and INSTAGRAM_ACCOUNT_ID are required to publish."
            )
        self.settings = settings
        self.base_url = (
            "https://graph.facebook.com/"
            f"{settings.meta_graph_api_version.strip('/')}"
        )
        self.headers = {"Authorization": f"Bearer {settings.meta_access_token}"}

    async def _request(
        self,
        method: str,
        path: str,
        *,
        data: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        try:
            async with httpx.AsyncClient(timeout=90) as client:
                response = await client.request(
                    method,
                    f"{self.base_url}/{path.lstrip('/')}",
                    headers=self.headers,
                    data=data,
                    params=params,
                )
        except httpx.RequestError:
            raise RuntimeError("Meta Graph API network request failed.") from None
        if response.is_error:
            raise RuntimeError(
                f"Meta Graph API request failed (HTTP {response.status_code})."
            )
        result = response.json()
        if "error" in result:
            error = result["error"]
            message = error.get("message", "Meta returned an API error.")
            if self.settings.meta_access_token:
                message = str(message).replace(
                    self.settings.meta_access_token, "[redacted]"
                )
            raise RuntimeError(f"Meta Graph API: {message}")
        return result

    async def create_reel_container(
        self, video_url: str, cover_url: str, caption: str
    ) -> str:
        result = await self._request(
            "POST",
            f"{self.settings.instagram_account_id}/media",
            data={
                "media_type": "REELS",
                "video_url": video_url,
                "cover_url": cover_url,
                "caption": caption[:2200],
                "share_to_feed": "true",
            },
        )
        container_id = result.get("id")
        if not container_id:
            raise RuntimeError("Meta did not return an Instagram media container ID.")
        return str(container_id)

    async def wait_until_ready(self, container_id: str) -> None:
        for attempt in range(self.settings.meta_processing_max_attempts):
            result = await self._request(
                "GET",
                container_id,
                params={"fields": "status_code"},
            )
            status = result.get("status_code")
            if status == "FINISHED":
                return
            if status in {"ERROR", "EXPIRED"}:
                raise RuntimeError(
                    f"Instagram media container reached status {status}."
                )
            if attempt + 1 < self.settings.meta_processing_max_attempts:
                await asyncio.sleep(self.settings.meta_processing_poll_seconds)
        raise TimeoutError("Instagram media processing timed out before publishing.")

    async def publish_container(self, container_id: str) -> dict[str, Any]:
        result = await self._request(
            "POST",
            f"{self.settings.instagram_account_id}/media_publish",
            data={"creation_id": container_id},
        )
        media_id = result.get("id")
        if not media_id:
            raise RuntimeError("Meta did not return the published Instagram media ID.")
        return {"media_id": str(media_id)}

    async def fetch_insights(self, media_id: str) -> dict[str, Any]:
        result = await self._request(
            "GET",
            f"{media_id}/insights",
            params={
                "metric": "reach,views,likes,comments,saved,shares",
            },
        )
        metrics: dict[str, Any] = {}
        for item in result.get("data", []):
            values = item.get("values", [])
            metrics[item["name"]] = values[0].get("value") if values else None
        return metrics