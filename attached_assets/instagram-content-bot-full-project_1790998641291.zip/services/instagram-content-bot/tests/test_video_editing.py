import asyncio
import json
import shutil
import subprocess
from pathlib import Path
from uuid import UUID

import pytest

from app.agents.contracts import PipelineContext
from app.agents.storyboard import ReelEditPlan
from app.agents.video_editing import VideoEditingAgent
from app.core.config import Settings
from app.core.storage import LocalMediaStorage


def _run(command: list[str]) -> subprocess.CompletedProcess[bytes]:
    return subprocess.run(
        command,
        check=True,
        capture_output=True,
        timeout=120,
    )


@pytest.mark.skipif(
    not shutil.which("ffmpeg") or not shutil.which("ffprobe"),
    reason="FFmpeg and ffprobe are required for the real multi-clip render test.",
)
def test_editor_renders_multiple_clips_in_ai_selected_order(tmp_path: Path) -> None:
    async def render() -> tuple[PipelineContext, dict[str, object]]:
        source_path = tmp_path / "source.mp4"
        _run(
            [
                "ffmpeg",
                "-hide_banner",
                "-loglevel",
                "error",
                "-y",
                "-f",
                "lavfi",
                "-i",
                "color=c=red:s=320x180:r=24:d=2",
                "-f",
                "lavfi",
                "-i",
                "color=c=green:s=320x180:r=24:d=2",
                "-f",
                "lavfi",
                "-i",
                "color=c=blue:s=320x180:r=24:d=2",
                "-f",
                "lavfi",
                "-i",
                "sine=frequency=440:sample_rate=48000:duration=6",
                "-filter_complex",
                "[0:v][1:v][2:v]concat=n=3:v=1:a=0,format=yuv420p[v]",
                "-map",
                "[v]",
                "-map",
                "3:a:0",
                "-c:v",
                "libx264",
                "-c:a",
                "aac",
                str(source_path),
            ]
        )

        storage = LocalMediaStorage(tmp_path / "storage")
        storage_path = storage.resolve("source.mp4")
        storage_path.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source_path, storage_path)
        context = PipelineContext(
            job_id=UUID(int=4),
            chat_id=123,
            telegram_user_id=456,
            media_token="test-token",
            source_key="source.mp4",
            work_dir=tmp_path / "work",
            settings=Settings(
                max_reel_duration_seconds=30,
                ffmpeg_font_name="DejaVu Sans",
            ),
            storage=storage,
            analysis={"duration_seconds": 6.0, "has_audio": True},
        )
        context.reel_edit_plan = ReelEditPlan.from_ai_response(
            {
                "concept": "سه نمای واقعی با ترتیب متفاوت",
                "hook_concepts": [
                    {
                        "start": 4.0,
                        "end": 6.0,
                        "text": "نمای آبی",
                        "reason": "نمای آبی قوی‌ترین تغییر تصویری را دارد.",
                    },
                    {
                        "start": 0.0,
                        "end": 2.0,
                        "text": "نمای قرمز",
                        "reason": "رنگ قرمز در قاب واضح است.",
                    },
                    {
                        "start": 2.0,
                        "end": 4.0,
                        "text": "نمای سبز",
                        "reason": "نمای سبز متفاوت است.",
                    },
                    {
                        "start": 0.5,
                        "end": 2.5,
                        "text": "تغییر رنگ بدنه",
                        "reason": "این گزینه یک قاب واضح از رنگ را نشان می‌دهد.",
                    },
                    {
                        "start": 3.0,
                        "end": 5.0,
                        "text": "یک نمای دیگر",
                        "reason": "سوژه در این بخش در مرکز است.",
                    },
                ],
                "selected_hook": {
                    "start": 4.0,
                    "end": 6.0,
                    "text": "نمای آبی",
                    "reason": "نمای آبی قوی‌ترین تغییر تصویری را دارد.",
                },
                "clips": [
                    {
                        "start": 4.0,
                        "end": 6.0,
                        "purpose": "hook",
                        "reason": "در این بخش رنگ و تغییر واضح است.",
                    },
                    {
                        "start": 0.0,
                        "end": 2.0,
                        "purpose": "before",
                        "reason": "این بخش بافت پیش از فرایند را نشان می‌دهد.",
                    },
                    {
                        "start": 2.0,
                        "end": 4.0,
                        "purpose": "final_result",
                        "reason": "این بخش نمای پایانی را نشان می‌دهد.",
                    },
                ],
                "target_duration": 6.0,
                "overlay_text": [],
                "cta": "برای مشاوره پیام بدهید",
            },
            video_duration=6.0,
            max_reel_duration=30.0,
        )
        return context, await VideoEditingAgent().run(context)

    context, result = asyncio.run(render())

    assert result["clip_count"] == 3
    assert result["clip_order"] == ["hook", "before", "final_result"]
    assert context.final_video_path is not None
    probe = _run(
        [
            "ffprobe",
            "-v",
            "error",
            "-show_streams",
            "-show_format",
            "-of",
            "json",
            str(context.final_video_path),
        ]
    )
    media = json.loads(probe.stdout)
    video = next(stream for stream in media["streams"] if stream["codec_type"] == "video")
    audio = next(stream for stream in media["streams"] if stream["codec_type"] == "audio")
    assert (video["width"], video["height"]) == (1080, 1920)
    assert video["codec_name"] == "h264"
    assert audio["codec_name"] == "aac"
    assert float(media["format"]["duration"]) == pytest.approx(6.0, abs=0.3)

    dominant_channels: list[int] = []
    for timestamp in (0.5, 2.5, 4.5):
        pixel = _run(
            [
                "ffmpeg",
                "-hide_banner",
                "-loglevel",
                "error",
                "-ss",
                str(timestamp),
                "-i",
                str(context.final_video_path),
                "-frames:v",
                "1",
                "-vf",
                "crop=2:2:540:960,format=rgb24,scale=1:1:flags=neighbor",
                "-f",
                "rawvideo",
                "-",
            ]
        ).stdout
        assert len(pixel) == 3
        dominant_channels.append(max(range(3), key=lambda channel: pixel[channel]))

    assert dominant_channels == [2, 0, 1]