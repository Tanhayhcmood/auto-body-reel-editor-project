import pytest

from app.agents.approval import ApprovalStateError, decide_approval


def test_only_awaiting_jobs_can_be_approved_or_rejected() -> None:
    assert decide_approval("awaiting_approval", "approve") == "approved"
    assert decide_approval("awaiting_approval", "reject") == "rejected"

    with pytest.raises(ApprovalStateError):
        decide_approval("published", "approve")
    with pytest.raises(ApprovalStateError):
        decide_approval("awaiting_approval", "publish")