from pathlib import Path
from uuid import UUID

import pytest

import app.agents.quality_control as quality_control
from app.agents.contracts import PipelineContext
from app.core.config import Settings
from app.core.storage import LocalMediaStorage


@pytest.mark.asyncio
async def test_quality_control_accepts_valid_9_by_16_mp4(tmp_path: Path, monkeypatch) -> None:
    video = tmp_path / "reel.mp4"
    cover = tmp_path / "cover.jpg"
    video.write_bytes(b"x" * 20_000)
    cover.write_bytes(b"x" * 2_000)

    async def fake_probe(_path):
        return {
            "format": {"duration": "35.0"},
            "streams": [
                {
                    "codec_type": "video",
                    "codec_name": "h264",
                    "width": 1080,
                    "height": 1920,
                }
            ],
        }

    monkeypatch.setattr(quality_control, "probe_video", fake_probe)
    context = PipelineContext(
        job_id=UUID(int=3),
        chat_id=10,
        telegram_user_id=20,
        media_token="token",
        source_key="original.mp4",
        work_dir=tmp_path / "work",
        settings=Settings(storage_dir=str(tmp_path)),
        storage=LocalMediaStorage(tmp_path),
    )
    context.final_video_path = video
    context.cover_path = cover

    result = await quality_control.QualityControlAgent().run(context)
    assert result["passed"] is True
    assert result["width"] == 1080
    assert result["height"] == 1920


@pytest.mark.asyncio
async def test_quality_control_rejects_landscape_output(tmp_path: Path, monkeypatch) -> None:
    video = tmp_path / "reel.mp4"
    cover = tmp_path / "cover.jpg"
    video.write_bytes(b"x" * 20_000)
    cover.write_bytes(b"x" * 2_000)

    async def fake_probe(_path):
        return {
            "format": {"duration": "35.0"},
            "streams": [
                {"codec_type": "video", "width": 1920, "height": 1080}
            ],
        }

    monkeypatch.setattr(quality_control, "probe_video", fake_probe)
    context = PipelineContext(
        job_id=UUID(int=4),
        chat_id=10,
        telegram_user_id=20,
        media_token="token",
        source_key="original.mp4",
        work_dir=tmp_path / "work",
        settings=Settings(storage_dir=str(tmp_path)),
        storage=LocalMediaStorage(tmp_path),
    )
    context.final_video_path = video
    context.cover_path = cover

    with pytest.raises(ValueError, match="9:16"):
        await quality_control.QualityControlAgent().run(context)