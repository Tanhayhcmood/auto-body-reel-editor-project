from pathlib import Path
from uuid import UUID

import pytest

from app.agents.caption import CaptionAgent
from app.agents.contracts import PipelineContext
from app.agents.storyboard import ReelEditPlan
from app.agents.video_editing import ass_time, build_ass, escape_ass
from app.core.config import Settings
from app.core.storage import LocalMediaStorage


@pytest.mark.asyncio
async def test_caption_agent_generates_persian_without_an_ai_key(tmp_path: Path) -> None:
    settings = Settings(storage_dir=str(tmp_path))
    storage = LocalMediaStorage(tmp_path)
    context = PipelineContext(
        job_id=UUID(int=1),
        chat_id=123,
        telegram_user_id=456,
        media_token="generated-at-runtime",
        source_key="input.mp4",
        work_dir=tmp_path / "work",
        settings=settings,
        storage=storage,
    )

    result = await CaptionAgent().run(context)

    assert result["mode"] == "persian_template"
    assert context.hook
    assert "صافکاری" in context.caption
    assert "دایرکت" in context.cta
    assert len(context.caption) <= 2200


def test_ass_timestamps_and_persian_text_are_escaped() -> None:
    assert ass_time(10.23) == "0:00:10.23"
    assert r"\{" in escape_ass("{تعمیر}")

    context = PipelineContext(
        job_id=UUID(int=2),
        chat_id=123,
        telegram_user_id=456,
        media_token="token",
        source_key="input.mp4",
        work_dir=Path("/tmp/instagram-bot-test"),
        settings=Settings(),
        storage=LocalMediaStorage("/tmp/instagram-bot-test-storage"),
    )
    context.reel_edit_plan = ReelEditPlan.from_ai_response(
        {
            "concept": "نمایش روند واقعی تعمیر",
            "hook_concepts": [
                {
                    "start": 5.0,
                    "end": 8.0,
                    "text": "نتیجه نهایی",
                    "reason": "تغییر واقعی در تصویر دیده می‌شود.",
                },
                {
                    "start": 8.0,
                    "end": 11.0,
                    "text": "این بخش مهم است",
                    "reason": "نمای نزدیک جزئیات را نشان می‌دهد.",
                },
                {
                    "start": 12.0,
                    "end": 15.0,
                    "text": "تعمیر از نزدیک",
                    "reason": "ابزار در حال حرکت قابل مشاهده است.",
                },
                {
                    "start": 16.0,
                    "end": 19.0,
                    "text": "نتیجه را از اینجا ببین",
                    "reason": "سطح بدنه واضح است.",
                },
                {
                    "start": 20.0,
                    "end": 23.0,
                    "text": "یک جزئیات واقعی",
                    "reason": "حرکت دست در تصویر واضح است.",
                },
            ],
            "selected_hook": {
                "start": 5.0,
                "end": 8.0,
                "text": "نتیجه نهایی",
                "reason": "تغییر واقعی در تصویر دیده می‌شود.",
            },
            "clips": [
                {
                    "start": 5.0,
                    "end": 8.0,
                    "purpose": "hook",
                    "reason": "نتیجه در این بخش واضح است.",
                },
                {
                    "start": 20.0,
                    "end": 24.0,
                    "purpose": "final_result",
                    "reason": "این بخش شواهد واقعی از نتیجه دارد.",
                },
            ],
            "target_duration": 7.0,
            "overlay_text": [],
            "cta": "برای مشاوره پیام بدهید",
        },
        video_duration=30.0,
        max_reel_duration=90.0,
    )
    context.hook = context.reel_edit_plan.hook.text
    context.transcript_segments = [
        {"start": 6.0, "end": 8.0, "text": "تعمیر بدنه"}
    ]

    subtitles = build_ass(context)
    assert "نتیجه نهایی" in subtitles
    assert "تعمیر بدنه" in subtitles
    assert "0:00:01.00,0:00:03.00" in subtitles