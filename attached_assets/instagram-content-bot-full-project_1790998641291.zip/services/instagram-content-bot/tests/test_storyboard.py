import json
from pathlib import Path
from uuid import UUID

import pytest
from pydantic import ValidationError

from app.agents.contracts import PipelineContext
from app.agents.storyboard import ReelEditPlan, StoryboardAgent
from app.core.config import Settings
from app.core.storage import LocalMediaStorage
from app.services.ai_provider import OpenAICompatibleProvider
from app.services.video_segmentation import (
    RepresentativeFrame,
    SegmentAnalysis,
    VideoSegment,
)


def valid_plan() -> dict[str, object]:
    concepts = [
        {
            "text": "این آسیب چطور برطرف می‌شود؟",
            "start": 12.0,
            "end": 15.0,
            "reason": "نمای واضح آسیب در نور مناسب دیده می‌شود.",
        },
        {
            "text": "نتیجه‌ی واقعی تعمیر را ببین",
            "start": 20.0,
            "end": 24.0,
            "reason": "تغییر قابل مشاهده‌ی سطح بدنه توجه‌برانگیز است.",
        },
        {
            "text": "این مرحله چه تغییری ایجاد می‌کند؟",
            "start": 1.0,
            "end": 4.0,
            "reason": "ابزار و محل کار در این نما مشخص هستند.",
        },
        {
            "text": "جزئیات کار از نزدیک",
            "start": 5.0,
            "end": 8.0,
            "reason": "نمای نزدیک جزئیات سطح را نشان می‌دهد.",
        },
        {
            "text": "ببینید چه چیزی واقعاً تغییر کرد",
            "start": 16.0,
            "end": 19.0,
            "reason": "این بخش پیوستگی بصری فرایند را نشان می‌دهد.",
        },
    ]
    return {
        "concept": "نمایش تغییر واقعی بدنه",
        "hook_concepts": concepts,
        "selected_hook": concepts[0].copy(),
        "clips": [
            {
                "start": 12.0,
                "end": 15.0,
                "purpose": "hook",
                "reason": "آسیب در اولین نما به‌وضوح دیده می‌شود.",
                "zoom": False,
            },
            {
                "start": 1.0,
                "end": 4.0,
                "purpose": "before",
                "reason": "این بخش وضعیت پیش از تعمیر را نشان می‌دهد.",
                "zoom": False,
            },
            {
                "start": 20.0,
                "end": 24.0,
                "purpose": "repair_process",
                "reason": "حرکت ابزار در این بخش قابل مشاهده است.",
                "zoom": True,
            },
        ],
        "target_duration": 10.0,
        "overlay_text": [{"start": 21.0, "end": 22.0, "text": "جزئیات کار"}],
        "cta": "برای مشاوره پیام بدهید",
    }


def segment_analysis(
    segment_id: str = "segment_001", start: float = 0.0, end: float = 4.5
) -> dict[str, object]:
    return {
        "segment_id": segment_id,
        "start": start,
        "end": end,
        "summary": "یک فرورفتگی روی بدنه دیده می‌شود و ابزار در حال حرکت است.",
        "visual_events": ["ابزار از چپ به راست روی ناحیه‌ی آسیب حرکت می‌کند."],
        "labels": ["damaged_area", "repair_process", "tools_action"],
        "quality_score": 0.9,
        "interest_score": 0.8,
        "repair_relevance": 1.0,
        "transformation_value": 0.6,
    }


def test_reel_edit_plan_accepts_five_hooks_and_ai_selected_clip_order() -> None:
    plan = ReelEditPlan.from_ai_response(
        valid_plan(), video_duration=30.0, max_reel_duration=90.0
    )

    assert len(plan.hook_concepts) == 5
    assert plan.selected_hook.text == plan.hook.text
    assert [clip.start for clip in plan.clips] == [12.0, 1.0, 20.0]
    assert plan.clips[2].reason
    assert sum(clip.end - clip.start for clip in plan.clips) == 10.0


def test_reel_edit_plan_rejects_timestamps_outside_uploaded_video() -> None:
    response = valid_plan()
    clips = response["clips"]
    assert isinstance(clips, list)
    clips[2] = {
        "start": 20.0,
        "end": 31.0,
        "purpose": "repair_process",
        "reason": "نمای واقعی ابزار در حال حرکت است.",
    }

    with pytest.raises(ValidationError, match="within the 30.000s source video"):
        ReelEditPlan.from_ai_response(
            response, video_duration=30.0, max_reel_duration=90.0
        )


def test_reel_edit_plan_requires_selected_hook_to_match_first_clip() -> None:
    response = valid_plan()
    hook_concepts = response["hook_concepts"]
    assert isinstance(hook_concepts, list)
    hook_concepts[0] = {
        **hook_concepts[0],
        "start": 13.0,
        "end": 15.0,
    }
    response["selected_hook"] = hook_concepts[0].copy()

    with pytest.raises(ValidationError, match="Hook timestamps must match"):
        ReelEditPlan.from_ai_response(
            response, video_duration=30.0, max_reel_duration=90.0
        )


def test_reel_edit_plan_keeps_hooks_and_clips_inside_analyzed_segments() -> None:
    response = valid_plan()
    clips = response["clips"]
    assert isinstance(clips, list)
    clips[1] = {
        **clips[1],
        "start": 3.0,
        "end": 6.0,
    }
    source_segments = [
        segment_analysis("segment_001", 0.0, 5.0),
        segment_analysis("segment_002", 5.0, 10.0),
        segment_analysis("segment_003", 10.0, 16.0),
        segment_analysis("segment_004", 16.0, 20.0),
        segment_analysis("segment_005", 20.0, 30.0),
    ]

    with pytest.raises(ValidationError, match="Every selected clip must fit"):
        ReelEditPlan.from_ai_response(
            response,
            video_duration=30.0,
            max_reel_duration=90.0,
            source_segments=source_segments,
        )


def test_segment_analysis_validates_allowed_labels_and_unit_scores() -> None:
    result = SegmentAnalysis.model_validate(segment_analysis())
    assert result.repair_relevance == 1.0
    assert result.labels == ["damaged_area", "repair_process", "tools_action"]

    invalid = segment_analysis()
    invalid["interest_score"] = 1.01
    with pytest.raises(ValidationError):
        SegmentAnalysis.model_validate(invalid)

    invalid = segment_analysis()
    invalid["labels"] = ["invented_event"]
    with pytest.raises(ValidationError):
        SegmentAnalysis.model_validate(invalid)


@pytest.mark.asyncio
async def test_segment_vision_request_keeps_frames_grouped_and_timestamped(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    frames = []
    for name in ("a.jpg", "b.jpg", "c.jpg", "d.jpg"):
        path = tmp_path / name
        path.write_bytes(f"frame-{name}".encode())
        frames.append(path)
    segments = [
        VideoSegment(
            segment_id="segment_001",
            start=0.0,
            end=4.0,
            duration=4.0,
            representative_frames=[
                RepresentativeFrame(timestamp=1.0, path=frames[0]),
                RepresentativeFrame(timestamp=3.0, path=frames[1]),
            ],
        ),
        VideoSegment(
            segment_id="segment_002",
            start=4.0,
            end=8.0,
            duration=4.0,
            representative_frames=[
                RepresentativeFrame(timestamp=5.0, path=frames[2]),
                RepresentativeFrame(timestamp=7.0, path=frames[3]),
            ],
        ),
    ]
    provider = OpenAICompatibleProvider(Settings(ai_api_key="test-only"))
    captured_messages: list[dict[str, object]] = []

    async def fake_chat(messages: list[dict[str, object]]) -> str:
        captured_messages.extend(messages)
        return json.dumps(
            {
                "segments": [
                    segment_analysis("segment_001", 0.0, 4.0),
                    segment_analysis("segment_002", 4.0, 8.0),
                ]
            }
        )

    monkeypatch.setattr(provider, "_chat", fake_chat)
    result = await provider.analyze_segments(segments)

    assert [item["segment_id"] for item in result] == [
        "segment_001",
        "segment_002",
    ]
    system_prompt = captured_messages[0]["content"]
    assert isinstance(system_prompt, str) and "توالی تصویری" in system_prompt
    content = captured_messages[1]["content"]
    assert isinstance(content, list)
    text_blocks = [
        block["text"]
        for block in content
        if isinstance(block, dict) and "text" in block
    ]
    assert any("segment_001" in text and "1.0000" in text for text in text_blocks)
    assert any("segment_002" in text and "7.0000" in text for text in text_blocks)
    assert sum(
        1
        for block in content
        if isinstance(block, dict) and block.get("type") == "image_url"
    ) == 4


@pytest.mark.asyncio
async def test_storyboard_repairs_invalid_ai_timestamps_once_and_saves_edit_plan(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    invalid_plan = valid_plan()
    invalid_clips = invalid_plan["clips"]
    assert isinstance(invalid_clips, list)
    invalid_clips[0] = {
        **invalid_clips[0],
        "start": 28.0,
        "end": 32.0,
    }
    hook_concepts = invalid_plan["hook_concepts"]
    assert isinstance(hook_concepts, list)
    hook_concepts[0] = {
        **hook_concepts[0],
        "start": 28.0,
        "end": 32.0,
    }
    invalid_plan["selected_hook"] = hook_concepts[0].copy()
    analyzed_segments = [
        segment_analysis("segment_001", 0.0, 10.0),
        segment_analysis("segment_002", 10.0, 16.0),
        segment_analysis("segment_003", 16.0, 20.0),
        segment_analysis("segment_004", 20.0, 30.0),
    ]

    class FakeProvider:
        enabled = True
        repair_calls = 0
        received_analysis: dict[str, object] | None = None

        async def generate_reel_edit_plan(
            self, **kwargs: object
        ) -> dict[str, object]:
            self.received_analysis = kwargs["analysis"]  # type: ignore[assignment]
            return invalid_plan

        async def repair_reel_edit_plan(
            self, **_kwargs: object
        ) -> dict[str, object]:
            self.repair_calls += 1
            return valid_plan()

    provider = FakeProvider()
    monkeypatch.setattr(
        "app.agents.storyboard.OpenAICompatibleProvider",
        lambda _settings: provider,
    )
    storage = LocalMediaStorage(tmp_path / "storage")
    context = PipelineContext(
        job_id=UUID(int=3),
        chat_id=123,
        telegram_user_id=456,
        media_token="test-token",
        source_key="input.mp4",
        work_dir=tmp_path / "work",
        settings=Settings(
            max_reel_duration_seconds=90,
            debug_ai_artifacts=True,
        ),
        storage=storage,
        analysis={
            "duration_seconds": 30.0,
            "scene_change_seconds": [4.0],
            "segments": analyzed_segments,
        },
    )

    result = await StoryboardAgent().run(context)

    assert provider.repair_calls == 1
    assert context.reel_edit_plan is not None
    assert result["selection_method"] == "ai_storyboard"
    assert context.hook == valid_plan()["selected_hook"]["text"]
    assert provider.received_analysis is not None
    assert provider.received_analysis["segments"] == analyzed_segments
    saved_plan = json.loads((context.work_dir / "edit-plan.json").read_text())
    assert len(saved_plan["hook_concepts"]) == 5
    assert saved_plan["selected_hook"]["text"] == context.hook