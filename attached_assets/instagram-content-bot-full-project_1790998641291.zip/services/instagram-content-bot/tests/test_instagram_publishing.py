from pathlib import Path
from uuid import UUID

import pytest

from app.agents.contracts import PipelineContext
from app.agents.instagram_publishing import InstagramPublishingAgent
from app.core.config import Settings
from app.core.storage import LocalMediaStorage


class FakeInstagramClient:
    def __init__(self):
        self.created = None
        self.published = None

    async def create_reel_container(self, video_url, cover_url, caption):
        self.created = (video_url, cover_url, caption)
        return "container-id"

    async def wait_until_ready(self, container_id):
        assert container_id == "container-id"

    async def publish_container(self, container_id):
        self.published = container_id
        return {"media_id": "published-media-id"}


@pytest.mark.asyncio
async def test_publisher_uses_public_assets_and_returns_meta_media_id(tmp_path: Path) -> None:
    settings = Settings(
        storage_dir=str(tmp_path),
        public_media_base_url="https://bot.example.test",
    )
    storage = LocalMediaStorage(tmp_path)
    context = PipelineContext(
        job_id=UUID(int=5),
        chat_id=10,
        telegram_user_id=20,
        media_token="random-media-token",
        source_key="source.mp4",
        work_dir=tmp_path / "work",
        settings=settings,
        storage=storage,
    )
    context.final_video_key = "job/reel.mp4"
    context.cover_file_key = "job/cover.jpg"
    context.caption = "کپشن فارسی"
    container_callbacks: list[str] = []

    async def remember_container(container_id: str) -> None:
        container_callbacks.append(container_id)

    context.on_container_created = remember_container
    client = FakeInstagramClient()

    result = await InstagramPublishingAgent(client).run(context)

    assert result["instagram_media_id"] == "published-media-id"
    assert container_callbacks == ["container-id"]
    assert client.created[0].endswith("/video")
    assert client.created[1].endswith("/cover")
    assert client.created[2] == "کپشن فارسی"
    assert client.published == "container-id"


def test_public_media_urls_require_a_public_base_url(tmp_path: Path) -> None:
    storage = LocalMediaStorage(tmp_path)
    with pytest.raises(RuntimeError, match="PUBLIC_MEDIA_BASE_URL"):
        storage.public_url("", "job", "token", "video")