import asyncio
import json
import shutil
import subprocess
from pathlib import Path
from uuid import UUID

import pytest

from app.agents.contracts import PipelineContext
from app.agents.video_analysis import VideoAnalysisAgent
from app.core.config import Settings
from app.core.storage import LocalMediaStorage
from app.services.video_segmentation import (
    RepresentativeFrame,
    SegmentAnalysis,
    VideoSegment,
    build_segment_ranges,
    create_video_segments,
)


def _run(command: list[str]) -> subprocess.CompletedProcess[bytes]:
    return subprocess.run(
        command,
        check=True,
        capture_output=True,
        timeout=120,
    )


def test_segment_ranges_combine_scene_cuts_and_time_sampling() -> None:
    ranges = build_segment_ranges(20.0, [3.0])

    assert ranges[0][0] == 0.0
    assert ranges[-1][1] == 20.0
    assert any(start == 0.0 and end == 3.0 for start, end in ranges)
    assert any(abs(end - 6.6667) < 0.001 for _, end in ranges)
    assert all(abs(left[1] - right[0]) < 0.0001 for left, right in zip(ranges, ranges[1:]))
    assert len(ranges) <= 16


def test_segment_ranges_cap_count_and_retain_scene_boundaries() -> None:
    ranges = build_segment_ranges(
        600.0,
        [float(timestamp) for timestamp in range(1, 120)],
    )
    boundaries = {start for start, _ in ranges} | {ranges[-1][1]}

    assert len(ranges) <= 16
    assert ranges[0][0] == 0.0
    assert ranges[-1][1] == 600.0
    assert any(
        abs(boundary - timestamp) < 0.001
        for boundary in boundaries
        for timestamp in range(2, 120)
    )


@pytest.mark.skipif(
    not shutil.which("ffmpeg"),
    reason="FFmpeg is required for representative-frame extraction.",
)
def test_video_segmentation_extracts_timestamped_frames_per_scene_and_time_segment(
    tmp_path: Path,
) -> None:
    source_path = tmp_path / "source.mp4"
    _run(
        [
            "ffmpeg",
            "-hide_banner",
            "-loglevel",
            "error",
            "-y",
            "-f",
            "lavfi",
            "-i",
            "color=c=red:s=320x180:r=24:d=4",
            "-f",
            "lavfi",
            "-i",
            "color=c=blue:s=320x180:r=24:d=8",
            "-filter_complex",
            "[0:v][1:v]concat=n=2:v=1:a=0,format=yuv420p[v]",
            "-map",
            "[v]",
            "-c:v",
            "libx264",
            str(source_path),
        ]
    )

    scene_changes, segments = asyncio.run(
        create_video_segments(source_path, 12.0, tmp_path / "work")
    )

    assert any(abs(timestamp - 4.0) < 0.25 for timestamp in scene_changes)
    assert len(segments) == 3
    assert segments[0].start == 0.0
    assert abs(segments[0].end - 4.0) < 0.25
    assert abs(segments[-1].end - 12.0) < 0.001
    representative_count = 0
    for segment in segments:
        assert segment.duration == pytest.approx(segment.end - segment.start)
        assert 2 <= len(segment.representative_frames) <= 4
        representative_count += len(segment.representative_frames)
        for frame in segment.representative_frames:
            assert segment.start <= frame.timestamp < segment.end
            assert frame.path.is_file()
            assert frame.path.stat().st_size > 0
    assert representative_count <= 48


@pytest.mark.asyncio
async def test_video_analysis_saves_segment_and_analysis_debug_json(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    frame_paths = [tmp_path / "frame-1.jpg", tmp_path / "frame-2.jpg"]
    for frame_path in frame_paths:
        frame_path.write_bytes(b"test-frame")
    segment = VideoSegment(
        segment_id="segment_001",
        start=0.0,
        end=3.0,
        duration=3.0,
        representative_frames=[
            RepresentativeFrame(timestamp=1.0, path=frame_paths[0]),
            RepresentativeFrame(timestamp=2.0, path=frame_paths[1]),
        ],
    )

    async def fake_probe(_path: Path) -> dict[str, object]:
        return {
            "streams": [{"codec_type": "video", "width": 320, "height": 180}],
            "format": {"duration": "3.0"},
        }

    async def fake_segmenter(
        _path: Path, _duration: float, _work_dir: Path
    ) -> tuple[list[float], list[VideoSegment]]:
        return [1.5], [segment]

    class FakeProvider:
        enabled = True

        async def analyze_segments(
            self, _segments: list[VideoSegment]
        ) -> list[dict[str, object]]:
            return [
                SegmentAnalysis.model_validate(
                    {
                        "segment_id": "segment_001",
                        "start": 0.0,
                        "end": 3.0,
                        "summary": "ابزار روی بدنه حرکت می‌کند.",
                        "visual_events": ["حرکت ابزار در نمای نزدیک دیده می‌شود."],
                        "labels": ["repair_process", "tools_action"],
                        "quality_score": 0.9,
                        "interest_score": 0.8,
                        "repair_relevance": 1.0,
                        "transformation_value": 0.4,
                    }
                ).model_dump(mode="json")
            ]

    monkeypatch.setattr("app.agents.video_analysis.probe_video", fake_probe)
    monkeypatch.setattr(
        "app.agents.video_analysis.create_video_segments", fake_segmenter
    )
    monkeypatch.setattr(
        "app.agents.video_analysis.OpenAICompatibleProvider",
        lambda _settings: FakeProvider(),
    )
    storage = LocalMediaStorage(tmp_path / "storage")
    context = PipelineContext(
        job_id=UUID(int=5),
        chat_id=123,
        telegram_user_id=456,
        media_token="debug-test",
        source_key="source.mp4",
        work_dir=tmp_path / "work",
        settings=Settings(ai_api_key="test-only", debug_ai_artifacts=True),
        storage=storage,
    )

    analysis = await VideoAnalysisAgent().run(context)

    segments_file = json.loads((context.work_dir / "segments.json").read_text())
    analysis_file = json.loads((context.work_dir / "analysis.json").read_text())
    assert segments_file[0]["segment_id"] == "segment_001"
    assert segments_file[0]["representative_frames"][0]["timestamp"] == 1.0
    assert analysis_file["segments"][0]["repair_relevance"] == 1.0
    assert analysis["model_mode"] == "ai_segment_vision"
    assert not (context.work_dir / "edit-plan.json").exists()