import httpx
import pytest

from app.core.config import Settings
from app.services.telegram_client import TelegramClient


def test_runtime_requires_private_telegram_allowlist() -> None:
    settings = Settings(
        database_url="postgresql+asyncpg://bot:local@localhost/bot",
        redis_url="redis://localhost:6379/0",
        telegram_bot_token="test-token",
        telegram_webhook_secret="test-webhook-secret",
    )

    with pytest.raises(RuntimeError, match="ALLOWED_TELEGRAM_USER_IDS"):
        settings.validate_runtime()


def test_runtime_accepts_numeric_telegram_allowlist() -> None:
    settings = Settings(
        database_url="postgresql+asyncpg://bot:local@localhost/bot",
        redis_url="redis://localhost:6379/0",
        telegram_bot_token="test-token",
        telegram_webhook_secret="test-webhook-secret",
        allowed_telegram_user_ids="12345,67890",
    )

    settings.validate_runtime()
    assert settings.allowed_user_ids == {12345, 67890}


async def test_telegram_network_errors_do_not_expose_bot_token(monkeypatch) -> None:
    token = "test-token-that-must-not-appear-in-errors"

    class BrokenClient:
        async def __aenter__(self):
            return self

        async def __aexit__(self, *_args):
            return None

        async def post(self, url, **_kwargs):
            raise httpx.ConnectError(f"request failed for {url}")

    monkeypatch.setattr(httpx, "AsyncClient", lambda **_kwargs: BrokenClient())
    telegram = TelegramClient(Settings(telegram_bot_token=token))

    with pytest.raises(RuntimeError) as error:
        await telegram.send_message(12345, "test")

    assert token not in str(error.value)