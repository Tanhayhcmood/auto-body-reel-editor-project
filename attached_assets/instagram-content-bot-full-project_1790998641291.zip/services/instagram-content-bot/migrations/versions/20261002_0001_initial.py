"""Initial bot, jobs, posts, analytics, and learning schema.

Revision ID: 20261002_0001
"""

from alembic import op

from app.models import Base

revision = "20261002_0001"
down_revision = None
branch_labels = None
depends_on = None


def upgrade() -> None:
    Base.metadata.create_all(bind=op.get_bind(), checkfirst=True)


def downgrade() -> None:
    Base.metadata.drop_all(bind=op.get_bind(), checkfirst=True)